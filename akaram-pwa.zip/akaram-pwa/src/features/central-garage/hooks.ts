import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { centralGarage } from '@sdk/central-garage.sdk'
import { exportGarageCsv, exportGarageReport, printGarageReport } from './export-report'
import { centralGarageKeys } from '@lib/query-keys/central-garage.keys'
import { API } from '@lib/constants/api.constants'
import { handleAppError } from '@lib/errors/error.handler'
import { useUiStore } from '@stores/ui.store'
import type { GarageReportFilter } from './reports'
import type { GarageHireInput } from './types'
import type { GarageFuelUnit } from './fuel-units'
import { buildFleetWorkbook, downloadWorkbook, type FleetImportRow } from './fleet-excel'
import { hrShifts } from '@sdk/hr-shifts.sdk'
import type {
  CreateGarageVehicleInput,
  GarageDashboardFilter,
  GarageFuelType,
  GarageShift,
  GarageTankZeroRequest,
  GarageVehicleFilter,
} from './types'

export function useGarageAreas() {
  return useQuery({
    queryKey: centralGarageKeys.areas(),
    queryFn: () => centralGarage.areas(),
    staleTime: API.STALE_TIME.REFERENCE,
  })
}
/** سائقو غرفة العمليات من HR — بحث حي، والنتيجة تُخزَّن لكل نص بحث */
export function useFleetDriverOptions(search = '', all = false, enabled = true) {
  return useQuery({
    queryKey: [...centralGarageKeys.all, 'driver-options', search.trim(), all],
    queryFn: () => centralGarage.driverOptions(search, all),
    staleTime: 30_000,
    enabled,
  })
}
export function useSetDepartureDriver() {
  const qc = useQueryClient(),
    toast = useUiStore((s) => s.addToast)
  const onError = useGarageMutationError('setDepartureDriver')
  return useMutation({
    mutationFn: (x: { departureId: string; driverEmployeeId: string; reason: string }) =>
      centralGarage.setDepartureDriver(x.departureId, x.driverEmployeeId, x.reason),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.all })
      toast({ type: 'success', message: 'تم تغيير سائق الانطلاقة وتسجيل السبب في التدقيق' })
    },
    onError,
  })
}
export function useGarageDashboard(filter: GarageDashboardFilter = {}) {
  return useQuery({
    queryKey: centralGarageKeys.dashboardSummary(filter),
    queryFn: () => centralGarage.dashboard(filter),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}
export function useGarageReport(filter: GarageReportFilter = {}) {
  return useQuery({
    queryKey: centralGarageKeys.report(filter),
    queryFn: () => centralGarage.report(filter),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}
export function useExportGarageReport() {
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('exportGarageReport')
  return useMutation({
    mutationFn: async (input: {
      filter: Omit<GarageReportFilter, 'page' | 'pageSize'>
      format: 'xlsx' | 'csv' | 'print'
      printWindow?: Window | null
    }) => {
      const result = await centralGarage.reportAll(input.filter)
      if (input.format === 'csv') exportGarageCsv(result)
      else if (input.format === 'print') printGarageReport(result, input.printWindow)
      else await exportGarageReport(result)
    },
    onSuccess: (_data, input) =>
      addToast({
        type: 'success',
        message:
          input.format === 'print'
            ? 'تم تجهيز التقرير الكامل للطباعة'
            : `تم إنشاء تقرير ${input.format === 'csv' ? 'CSV للبيانات الخام' : 'Excel'} الكامل`,
      }),
    onError: (error, input) => {
      input.printWindow?.close()
      onError(error)
    },
  })
}
export function useGarageVehicles(filter: GarageVehicleFilter = {}) {
  return useQuery({
    queryKey: centralGarageKeys.vehicleList(filter),
    queryFn: () => centralGarage.vehicles(filter),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}
export function useGarageVehicle(id: string) {
  return useQuery({
    queryKey: centralGarageKeys.vehicle(id),
    queryFn: () => centralGarage.vehicle(id),
    enabled: Boolean(id),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}
export function useGarageAssignments(id: string) {
  return useQuery({
    queryKey: centralGarageKeys.assignments(id),
    queryFn: () => centralGarage.assignmentHistory(id),
    enabled: Boolean(id),
  })
}
export function useGarageVehicleMovements(id: string) {
  return useQuery({
    queryKey: centralGarageKeys.movements(id),
    queryFn: () => centralGarage.movements({ vehicleId: id }),
    enabled: Boolean(id),
  })
}

function useGarageMutationError(scope: string) {
  const addToast = useUiStore((state) => state.addToast)
  return (error: unknown) =>
    addToast({ type: 'error' as const, message: handleAppError(error, { scope }).message })
}

export function useCreateGarageVehicle() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('createGarageVehicle')
  return useMutation({
    mutationFn: (input: CreateGarageVehicleInput) => centralGarage.createVehicle(input),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicles() })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.dashboard() })
      addToast({ type: 'success', message: 'تمت إضافة الآلية بنجاح' })
    },
    onError,
  })
}
/** 00182: استيراد الآليات من Excel (محاكاة أو تنفيذ) */
export function useFleetImport() {
  const qc = useQueryClient()
  const onError = useGarageMutationError('fleetImport')
  return useMutation({
    mutationFn: (x: { rows: FleetImportRow[]; dryRun: boolean; updateExisting: boolean }) => centralGarage.fleetImport(x.rows, x.dryRun, x.updateExisting),
    onSuccess: (_r, x) => { if (!x.dryRun) { void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicles() }); void qc.invalidateQueries({ queryKey: centralGarageKeys.dashboard() }) } },
    onError,
  })
}
/** 00182: تصدير قاعدة بيانات الآليات إلى Excel (الملف نفسه قالب الاستيراد) */
export function useFleetExport() {
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('fleetExport')
  return useMutation({
    mutationFn: async (template: boolean) => {
      const rows = template ? [] : await centralGarage.fleetExport()
      const shifts = await hrShifts.options(true).catch(() => null)
      const wb = await buildFleetWorkbook(rows, { template, shifts })
      await downloadWorkbook(wb, template ? 'قالب-قاعدة-بيانات-الآليات.xlsx' : `قاعدة-بيانات-الآليات-${new Date().toISOString().slice(0, 10)}.xlsx`)
      return rows.length
    },
    onSuccess: (n, template) => addToast({ type: 'success', message: template ? 'نُزّل قالب الاستيراد' : `صُدّرت ${n} آلية` }),
    onError,
  })
}
export function useUpdateGarageVehicle() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('updateGarageVehicle')
  return useMutation({
    mutationFn: (input: {
      id: string
      vehicleName: string
      dbNumber: string
      plateNumber: string
      chassisNumber: string
      image?: File
    }) => centralGarage.updateVehicle(input.id, input),
    onSuccess: (_data, input) => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicle(input.id) })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicles() })
      addToast({ type: 'success', message: 'تم تحديث بيانات الآلية' })
    },
    onError,
  })
}
export function useAssignGarageDriver() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('assignGarageDriver')
  return useMutation({
    mutationFn: (input: {
      vehicleId: string
      driverEmployeeId: string | null
      driverExternalId?: string | null
      shift: GarageShift
      sectorId: number
      reason?: string
    }) =>
      centralGarage.assignDriver(
        input.vehicleId,
        input.driverEmployeeId,
        input.shift,
        input.sectorId,
        input.reason,
        input.driverExternalId ?? null,
      ),
    onSuccess: (_data, input) => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicle(input.vehicleId) })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicles() })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.assignments(input.vehicleId) })
      addToast({ type: 'success', message: 'تم تحديث انطلاقية السائق وحفظ السجل السابق' })
    },
    onError,
  })
}
export function useArchiveGarageVehicle() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('archiveGarageVehicle')
  return useMutation({
    mutationFn: ({ vehicleId, reason }: { vehicleId: string; reason: string }) =>
      centralGarage.archiveVehicle(vehicleId, reason),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicles() })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.dashboard() })
      addToast({ type: 'warning', message: 'نُقلت الآلية إلى الأرشيف' })
    },
    onError,
  })
}
export function useRestoreGarageVehicle() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('restoreGarageVehicle')
  return useMutation({
    mutationFn: ({ vehicleId, reason }: { vehicleId: string; reason: string }) =>
      centralGarage.restoreVehicle(vehicleId, reason),
    onSuccess: (_data, input) => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicles() })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicle(input.vehicleId) })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.assignments(input.vehicleId) })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.dashboard() })
      addToast({ type: 'success', message: 'تمت استعادة الآلية وإعادة تفعيل انطلاقتها' })
    },
    onError,
  })
}

export function useGarageTanks(fuelType?: GarageFuelType) {
  return useQuery({
    queryKey: centralGarageKeys.tankList(fuelType),
    queryFn: () => centralGarage.tanks(fuelType),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}
export function useAssignGarageTankSector() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  const onError = useGarageMutationError('assignGarageTankSector')
  return useMutation({
    mutationFn: (input: {
      tankId: string
      parentSector: string
    }) => centralGarage.assignTankSector(input.tankId, input.parentSector),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.tanks() })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.dashboard() })
      addToast({ type: 'success', message: 'تم ربط الخزان بالكراج المحدد' })
    },
    onError,
  })
}

export function useGarageTankMovements(tankId: string) {
  return useQuery({
    queryKey: centralGarageKeys.tankMovements(tankId),
    queryFn: () => centralGarage.movements({ tankId }),
    enabled: Boolean(tankId),
  })
}
export function useGarageZeroRequests(status?: GarageTankZeroRequest['status']) {
  return useQuery({
    queryKey: centralGarageKeys.zeroRequests(status),
    queryFn: () => centralGarage.zeroRequests(status),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useGarageDepartures() {
  return useQuery({
    queryKey: centralGarageKeys.departures(),
    queryFn: () => centralGarage.todayDepartures(),
    staleTime: API.STALE_TIME.DEFAULT,
    refetchInterval: 30_000,
  })
}
export function useGarageDepartureDays() {
  return useQuery({
    queryKey: ['central-garage', 'departure-days'],
    queryFn: () => centralGarage.departureDays(),
    staleTime: API.STALE_TIME.DEFAULT,
    refetchInterval: 30_000,
  })
}
export function useGarageDeparturesForDay(day: string) {
  return useQuery({
    queryKey: ['central-garage', 'departures', 'day', day],
    queryFn: () => centralGarage.departuresForDay(day),
    enabled: Boolean(day),
    staleTime: API.STALE_TIME.DEFAULT,
    refetchInterval: 30_000,
  })
}
export function useGarageShiftAssignments(vehicleId: string) {
  return useQuery({
    queryKey: ['central-garage', 'shift-assignments', vehicleId],
    queryFn: () => centralGarage.shiftAssignments(vehicleId),
    enabled: Boolean(vehicleId),
  })
}
export function useGarageShiftDispatchRecipients(vehicleId: string, shift: GarageShift) {
  return useQuery({
    queryKey: ['central-garage', 'shift-recipients', vehicleId, shift],
    queryFn: () => centralGarage.shiftDispatchRecipients(vehicleId, shift),
    enabled: Boolean(vehicleId && shift),
  })
}
export function useSetGarageShiftAssignment() {
  const qc = useQueryClient(),
    toast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (x: {
      vehicleId: string
      shift: GarageShift
      driverEmployeeId: string | null
      driverExternalId?: string | null
      role?: 'primary' | 'backup'
      sectorId: number
      reason: string
    }) =>
      centralGarage.setShiftAssignment(
        x.vehicleId,
        x.shift,
        x.driverEmployeeId,
        x.sectorId,
        x.reason,
        x.role ?? 'primary',
        x.driverExternalId ?? null,
      ),
    onSuccess: (_, x) => {
      void qc.invalidateQueries({ queryKey: ['central-garage', 'shift-assignments', x.vehicleId] })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicle(x.vehicleId) })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.vehicles() })
      toast({
        type: 'success',
        message:
          x.role === 'backup'
            ? 'تم حفظ السائق الاحتياطي للشفت مع الاحتفاظ بالسجل'
            : 'تم حفظ سائق وموقع الشفت مع الاحتفاظ بالسجل',
      })
    },
  })
}
/** إنهاء إسناد سائق احتياطي */
export function useEndGarageShiftAssignment() {
  const qc = useQueryClient(),
    toast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (x: { assignmentId: string; vehicleId: string; reason: string }) =>
      centralGarage.endShiftAssignment(x.assignmentId, x.reason),
    onSuccess: (_, x) => {
      void qc.invalidateQueries({ queryKey: ['central-garage', 'shift-assignments', x.vehicleId] })
      toast({ type: 'success', message: 'أُنهي إسناد السائق الاحتياطي' })
    },
  })
}
export function useRecordGarageShiftDeparture() {
  const qc = useQueryClient(),
    toast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (x: {
      vehicleId: string
      shift: GarageShift
      notes?: string
      managerId?: string
      driverRole?: 'primary' | 'backup'
    }) =>
      centralGarage.recordShiftDeparture(x.vehicleId, x.shift, x.notes, x.managerId, x.driverRole ?? 'primary'),
    onSuccess: (_data, vars) => {
      void qc.invalidateQueries({ queryKey: ['central-garage'] })
      toast({
        type: 'success',
        message: vars.managerId
          ? 'سُجلت الانطلاقية وأُبلغ المسؤول المختار يدوياً'
          : 'سُجلت الانطلاقية وأُبلغ مسؤول المنطقة تلقائياً',
      })
    },
    onError: (error: unknown) => {
      const raw = error instanceof Error ? error.message : String(error)
      const message = raw.includes('GARAGE_SECTOR_MANAGER_NOT_CONFIGURED')
        ? 'لا يوجد مسؤول مهيأ لهذه المنطقة ولا لأي منطقة ضمن القاطع. حدّث ملفات مسؤولي القسم أولاً.'
        : raw.includes('GARAGE_RECIPIENT_NOT_ELIGIBLE')
          ? 'المسؤول المختار غير مؤهل لهذه المنطقة. اختر مسؤولاً يغطي المنطقة أو قاطعها.'
          : handleAppError(error, { scope: 'recordGarageShiftDeparture' }).message
      toast({ type: 'error', message })
    },
  })
}
export function useGarageDispatchRecipients(vehicleId: string) {
  return useQuery({
    queryKey: ['central-garage', 'dispatch-recipients', vehicleId],
    queryFn: () => centralGarage.dispatchRecipients(vehicleId),
    enabled: Boolean(vehicleId),
  })
}
export function useRecordGarageDeparture() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('recordGarageDeparture')
  return useMutation({
    mutationFn: (x: { vehicleId: string; notes?: string }) =>
      centralGarage.recordDeparture(x.vehicleId, x.notes),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.departures() })
      void qc.invalidateQueries({ queryKey: ['central-garage', 'departure-days'] })
      void qc.invalidateQueries({ queryKey: ['central-garage', 'departures', 'day'] })
      addToast({ type: 'success', message: 'سُجّل انطلاق السائق من الكراج إلى ورديته' })
    },
    onError,
  })
}
export function useRecordGarageReturn() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  const onError = useGarageMutationError('recordGarageReturn')
  return useMutation({
    mutationFn: (x: { departureId: string }) => centralGarage.recordReturn(x.departureId),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.departures() })
      void qc.invalidateQueries({ queryKey: ['central-garage', 'departure-days'] })
      void qc.invalidateQueries({ queryKey: ['central-garage', 'departures', 'day'] })
      addToast({ type: 'success', message: 'سُجّلت عودة الآلية إلى الكراج' })
    },
    onError,
  })
}
function useInvalidateGarageFuel() {
  const qc = useQueryClient()
  return () => {
    void qc.invalidateQueries({ queryKey: centralGarageKeys.tanks() })
    void qc.invalidateQueries({ queryKey: centralGarageKeys.dashboard() })
  }
}
export function useAddGarageTank() {
  const invalidate = useInvalidateGarageFuel()
  const addToast = useUiStore((s) => s.addToast)
  const onError = useGarageMutationError('addGarageTank')
  return useMutation({
    mutationFn: (x: {
      fuelType: GarageFuelType
      tankName: string
      unit?: GarageFuelUnit
      capacity: number
      initialQuantity: number
      lowStockThreshold: number
    }) =>
      centralGarage.addTank(
        x.fuelType,
        x.tankName,
        x.unit ?? 'liter',
        x.capacity,
        x.initialQuantity,
        x.lowStockThreshold,
      ),
    onSuccess: () => {
      invalidate()
      addToast({ type: 'success', message: 'تم إنشاء الخزان وتسجيل الكمية الابتدائية' })
    },
    onError,
  })
}
export function useAddGarageTankStock() {
  const qc = useQueryClient()
  const invalidate = useInvalidateGarageFuel()
  const addToast = useUiStore((s) => s.addToast)
  const onError = useGarageMutationError('addGarageTankStock')
  return useMutation({
    mutationFn: (x: { tankId: string; quantity: number; notes?: string }) =>
      centralGarage.addTankStock(x.tankId, x.quantity, x.notes),
    onSuccess: (_d, x) => {
      invalidate()
      void qc.invalidateQueries({ queryKey: centralGarageKeys.tankMovements(x.tankId) })
      addToast({ type: 'success', message: 'تمت إضافة الكمية إلى الخزان' })
    },
    onError,
  })
}

export function useFillGarageVehicle() {
  const qc = useQueryClient()
  const invalidate = useInvalidateGarageFuel()
  const addToast = useUiStore((s) => s.addToast)
  const onError = useGarageMutationError('fillGarageVehicle')
  return useMutation({
    mutationFn: (x: {
      tankId: string
      vehicleId: string
      quantity: number
      nextRefillDate?: string
      notes?: string
    }) => centralGarage.fillVehicle(x.tankId, x.vehicleId, x.quantity, x.nextRefillDate, x.notes),
    onSuccess: (_d, x) => {
      invalidate()
      void qc.invalidateQueries({ queryKey: centralGarageKeys.tankMovements(x.tankId) })
      void qc.invalidateQueries({ queryKey: centralGarageKeys.movements(x.vehicleId) })
      addToast({ type: 'success', message: 'تمت تعبئة الآلية وخصم الكمية من الخزان' })
    },
    onError,
  })
}
export function useRequestGarageTankZero() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  const onError = useGarageMutationError('requestGarageTankZero')
  return useMutation({
    mutationFn: (x: { tankId: string; reason: string }) =>
      centralGarage.requestTankZero(x.tankId, x.reason),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.tanks() })
      addToast({ type: 'success', message: 'أُرسل طلب التصفير إلى بوابة التطوير المركزية' })
    },
    onError,
  })
}
export function useDecideGarageTankZero() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  const onError = useGarageMutationError('decideGarageTankZero')
  return useMutation({
    mutationFn: (x: { requestId: string; approved: boolean; note?: string }) =>
      centralGarage.decideTankZero(x.requestId, x.approved, x.note),
    onSuccess: (_d, x) => {
      void qc.invalidateQueries({ queryKey: centralGarageKeys.tanks() })
      addToast({
        type: x.approved ? 'success' : 'warning',
        message: x.approved ? 'تمت الموافقة وتصفير الخزان' : 'تم رفض طلب التصفير',
      })
    },
    onError,
  })
}

/** 00207: موظفو الكراج */
export function useGarageEmployees(q: string, month: string) {
  return useQuery({ queryKey: centralGarageKeys.employees(q, month), queryFn: () => centralGarage.employees(q || null, month || null), staleTime: 60_000 })
}

/** 00208: ملخص طلبات الكراج */
export function useGarageLeavesSummary() {
  return useQuery({ queryKey: centralGarageKeys.leavesSummary(), queryFn: () => centralGarage.leavesSummary(), staleTime: 15_000 })
}

/** 00209: الإجراءات — التعيين الأساسي */
export function useGarageHireOptions() {
  return useQuery({ queryKey: centralGarageKeys.hireOptions(), queryFn: () => centralGarage.hireOptions(), staleTime: 60_000 })
}
export function useGarageRecentHires() {
  return useQuery({ queryKey: centralGarageKeys.recentHires(), queryFn: () => centralGarage.recentHires(), staleTime: 15_000 })
}
/** 00348: طلب تعيين (بلا موظف حتى موافقة السلسلة وإكمال الموارد البشرية) */
export function useGarageHire() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (v: GarageHireInput) => centralGarage.hire(v),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: centralGarageKeys.all }) },
  })
}
export function useMyHireRequests() {
  return useQuery({ queryKey: centralGarageKeys.hireRequests(), queryFn: () => centralGarage.myHireRequests(), staleTime: 15_000 })
}
export function useCancelHireRequest() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => centralGarage.cancelHireRequest(id),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: centralGarageKeys.hireRequests() }) },
  })
}
