import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { approvals, procedures, sectorManager, type TerminationType, type ApprovalRequestType, type ApprovalChainRequestType, type ApprovalStep, type ParentSector } from '@sdk/sector-manager.sdk'
import { useUiStore } from '@stores/ui.store'
import { handleAppError } from '@lib/errors/error.handler'

const ROOT = ['sector-manager']
const useAction = <T, R = unknown>(fn: (x: T) => Promise<R>, message: string | ((r: R) => string)) => {
  const qc = useQueryClient(), toast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: fn,
    onSuccess: (r) => { void qc.invalidateQueries({ queryKey: ROOT }); void qc.invalidateQueries({ queryKey: ['hr'] }); toast({ type: 'success', message: typeof message === 'function' ? message(r) : message }) },
    onError: (e) => toast({ type: 'error', message: handleAppError(e, { scope: 'sector-manager' }).message }),
  })
}
// التطوير المركزية
export const useSectorManagerOptions = (enabled = true) => useQuery({ queryKey: [...ROOT, 'options'], queryFn: () => sectorManager.options(), enabled })
export const useSectorManagerProfile = (userId: string | undefined) => useQuery({ queryKey: [...ROOT, 'profile', userId], queryFn: () => sectorManager.profileForUser(userId as string), enabled: Boolean(userId) })
export const useSaveSectorManagerProfile = () => useAction((x: { userId: string; parentSectors: ParentSector[]; notes?: string | null }) => sectorManager.saveProfile(x.userId, x.parentSectors, x.notes), 'حُفظت قواطع مسؤول القاطع')
// البوابة
export const useSectorManagerMe = () => useQuery({ queryKey: [...ROOT, 'me'], queryFn: () => sectorManager.me() })
export const useSectorTeam = () => useQuery({ queryKey: [...ROOT, 'team'], queryFn: () => sectorManager.team(), refetchInterval: 60_000 })
export const useSectorDashboard = () => useQuery({ queryKey: [...ROOT, 'dashboard'], queryFn: () => sectorManager.dashboard(), refetchInterval: 60_000 })
export const useSectorReports = (from?: string, to?: string) => useQuery({ queryKey: [...ROOT, 'reports', from ?? '', to ?? ''], queryFn: () => sectorManager.reports(from, to) })
export const useFieldOpsSectorManagers = () => useQuery({ queryKey: [...ROOT, 'fo-sector-managers'], queryFn: () => sectorManager.fieldOpsSectorManagers(), refetchInterval: 60_000 })
export const useNotifyTargets = () => useQuery({ queryKey: [...ROOT, 'notify-targets'], queryFn: () => sectorManager.notifyTargets() })
export const useSectorNotices = () => useQuery({ queryKey: [...ROOT, 'notices'], queryFn: () => sectorManager.notices() })
export const useSendSectorNotice = () => useAction((x: { title: string; body: string; targets?: string[] }) => sectorManager.notify(x.title, x.body, x.targets), (n) => `أُرسل التبليغ إلى ${n} من مسؤولي الأقسام`)
// 00261: متابعة المتعهدين والعمال
export const useSmContractors = (date?: string | null, contractor?: string | null, parent?: ParentSector | null) =>
  useQuery({ queryKey: [...ROOT, 'contractors', date ?? '', contractor ?? '', parent ?? ''], queryFn: () => sectorManager.contractors(date, contractor, parent), refetchInterval: 60_000 })
export const useSmSetContractorHeadcount = () => useAction((x: { contractorUserId: string; headcount: number }) => sectorManager.setContractorHeadcount(x.contractorUserId, x.headcount), 'حُفظ عدد القاطع')
export const useSmContractorMonth = (contractorUserId: string | null, month?: string | null) =>
  useQuery({ queryKey: [...ROOT, 'contractor-month', contractorUserId, month ?? ''], queryFn: () => sectorManager.contractorMonth(contractorUserId as string, month), enabled: Boolean(contractorUserId) })
export const useSmContractorsSummary = () => useQuery({ queryKey: [...ROOT, 'contractors-summary'], queryFn: () => sectorManager.contractorsSummary(), refetchInterval: 60_000 })
// سلاسل الموافقات
export const useApprovalChains = (enabled = true) => useQuery({ queryKey: [...ROOT, 'chains'], queryFn: () => approvals.chains(), enabled })
export const useSaveApprovalChain = () => useAction((x: { requesterRole: string; requestType: ApprovalChainRequestType; steps: ApprovalStep[]; active?: boolean; subtype?: string | null; department?: string | null; includeChildren?: boolean }) => approvals.saveChain(x.requesterRole, x.requestType, x.steps, x.active ?? true, x.subtype ?? null, x.department ?? null, x.includeChildren ?? true), 'حُفظت سلسلة الموافقات')
/** 00391 */
export const useApprovalEmployeeLookup = (q: string) => useQuery({ queryKey: [...ROOT, 'employee-lookup', q.trim()], queryFn: () => approvals.employeeLookup(q), enabled: q.trim().length >= 2, staleTime: 30_000 })
export const useApprovalDiagnose = (employeeId: string | null | undefined, type: ApprovalRequestType, subtype: string | null = null, enabled = true) =>
  useQuery({ queryKey: [...ROOT, 'diagnose', employeeId, type, subtype], queryFn: () => approvals.diagnose(employeeId as string, type, subtype), enabled: enabled && Boolean(employeeId), staleTime: 10_000 })
export const useDeleteApprovalChain = () => useAction((id: string) => approvals.deleteChain(id), 'حُذفت السلسلة')
export const useApprovalChainVersions = (chainId: string | null) => useQuery({ queryKey: [...ROOT, 'chain-versions', chainId], queryFn: () => approvals.chainVersions(chainId as string), enabled: Boolean(chainId) })
export const useApprovalSimulate = () => useMutation({ mutationFn: (x: { userId: string; type: ApprovalRequestType; subtype: string | null; context: Record<string, number> }) => approvals.simulate(x.userId, x.type, x.subtype, x.context) })
export const useApprovalDelegations = (all = false, enabled = true) => useQuery({ queryKey: [...ROOT, 'delegations', all], queryFn: () => approvals.delegations(all), enabled })
export const useSetApprovalDelegation = () => useAction((x: { toUser: string; startsOn: string; endsOn: string; note?: string | null; fromUser?: string | null }) => approvals.delegationSet(x), 'تم تفعيل التفويض وإشعار المفوَّض إليه')
export const useCancelApprovalDelegation = () => useAction((id: string) => approvals.delegationCancel(id), 'أُلغي التفويض')
export const useApprovalPerformance = (from: string, to: string) => useQuery({ queryKey: [...ROOT, 'performance', from, to], queryFn: () => approvals.performance(from, to), enabled: Boolean(from && to) })
export const useMyApprovalTasks = () => useQuery({ queryKey: [...ROOT, 'tasks'], queryFn: () => approvals.myTasks(), refetchInterval: 60_000 })
export const useApprovalTimeline = (kind: ApprovalRequestType | undefined, requestId: string | undefined) =>
  useQuery({ queryKey: [...ROOT, 'timeline', kind, requestId], queryFn: () => approvals.timeline(kind as ApprovalRequestType, requestId as string), enabled: Boolean(kind && requestId) })
export const useDecideApproval = () => useAction((x: { kind: ApprovalRequestType; requestId: string; approve: boolean; note?: string | null }) => approvals.decide(x.kind, x.requestId, x.approve, x.note), 'تم تسجيل قرارك')
// 00163: الإجراءات (إنهاء الخدمة)
export const useTerminationTargets = () => useQuery({ queryKey: [...ROOT, 'termination-targets'], queryFn: () => procedures.targets() })
export const useMyTerminationRequests = () => useQuery({ queryKey: [...ROOT, 'termination-mine'], queryFn: () => procedures.mine(), refetchInterval: 60_000 })
export const useCreateTerminationRequest = () => useAction((x: { targetKind: 'employee' | 'worker'; targetId: string; type: TerminationType; lastDay: string; reason: string }) => procedures.create(x), 'أُرسل طلب إنهاء الخدمة إلى سلسلة الموافقات')
export const useCancelTerminationRequest = () => useAction((id: string) => procedures.cancel(id), 'سُحب الطلب')
