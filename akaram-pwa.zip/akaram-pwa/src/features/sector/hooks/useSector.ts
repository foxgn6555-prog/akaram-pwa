/** خطافات وحدة «مسؤول القسم» */
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { sectorKeys } from '@lib/query-keys/sector.keys'
import { API } from '@lib/constants/api.constants'
import { handleAppError } from '@lib/errors/error.handler'
import { useUiStore } from '@stores/ui.store'
import {
  sector,
  sectorTeam,
  sectorSupplies,
  sectorBreakdowns,
  sectorPhotos,
  sectorAttendance,
  sectorSummary as fetchSummary,
  sectorVehicleTrips,
  sectorSupport,
} from '@sdk/sector.sdk'
import type {
  CreateWorkerInput,
  CreateVehicleInput,
  CreateSupplyInput,
  CreateBreakdownInput,
  CreateAttendanceInput,
} from '../types'

/* ── القواطع وملف المدير ── */
export function useSectors() {
  return useQuery({
    queryKey: sectorKeys.sectors(),
    queryFn: () => sector.listSectors(),
    staleTime: API.STALE_TIME.REFERENCE,
  })
}

export function useManagerProfile() {
  return useQuery({
    queryKey: sectorKeys.profile(),
    queryFn: () => sector.myProfile(),
    staleTime: API.STALE_TIME.REFERENCE,
  })
}

export function useManagerProfileForUser(userId: string) {
  return useQuery({
    queryKey: ['sector', 'manager-profile', userId],
    queryFn: () => sector.managerProfileForUser(userId),
    enabled: Boolean(userId),
  })
}

export function useSaveManagerProfile() {
  const qc = useQueryClient()
  const addToast = useUiStore((state) => state.addToast)
  return useMutation({
    mutationFn: (input: {
      userId: string
      shift: string
      sectors: number[]
    }) => sector.upsertManagerProfile(input.userId, input.shift, input.sectors),
    onSuccess: (_data, input) => {
      void qc.invalidateQueries({ queryKey: ['sector', 'manager-profile', input.userId] })
      void qc.invalidateQueries({ queryKey: ['central-garage', 'shift-recipients'] })
      addToast({ type: 'success', message: 'حُفظت مناطق مسؤول القسم وستظهر آلياته تلقائياً' })
    },
    onError: (error) =>
      addToast({
        type: 'error',
        message: handleAppError(error, { scope: 'saveManagerProfile' }).message,
      }),
  })
}

/* ── الفريق: عمال ── */
export function useWorkers(active = true) {
  return useQuery({
    queryKey: sectorKeys.workers(active ? 'active' : 'archived'),
    queryFn: () => sectorTeam.listWorkers(active),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useCreateWorker() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (input: CreateWorkerInput) => sectorTeam.createWorker(input),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'success', message: 'أُضيف العامل إلى فريقك' })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'createWorker' }).message }),
  })
}

export function useArchiveWorker() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      sectorTeam.archiveWorker(id, reason),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'warning', message: 'نُقل العامل إلى الأرشيف' })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'archiveWorker' }).message }),
  })
}

/* ── الفريق: آليات ── */
export function useVehicles(active = true) {
  return useQuery({
    queryKey: sectorKeys.vehicles(active ? 'active' : 'archived'),
    queryFn: () => sectorTeam.listVehicles(active),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useCreateVehicle() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (input: CreateVehicleInput) => sectorTeam.createVehicle(input),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'success', message: 'أُضيفت الآلية إلى قواطعك' })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'createVehicle' }).message }),
  })
}

export function useArchiveVehicle() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      sectorTeam.archiveVehicle(id, reason),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'warning', message: 'نُقلت الآلية إلى الأرشيف' })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'archiveVehicle' }).message }),
  })
}

/* ── طلبات المستلزمات ── */
export function useSupplies(scope: 'active' | 'archived' = 'active') {
  return useQuery({
    queryKey: sectorKeys.supplies(scope),
    queryFn: () => sectorSupplies.list(scope),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useSubmitSupply() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (input: CreateSupplyInput) => sectorSupplies.create(input),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'success', message: 'أُرسل كتاب طلب المستلزمات إلى معاون المدير المفوض' })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'submitSupply' }).message }),
  })
}

/* ── بلاغات الأعطال ── */
export function useBreakdowns(scope: 'active' | 'archived' = 'active') {
  return useQuery({
    queryKey: sectorKeys.breakdowns(scope),
    queryFn: () => sectorBreakdowns.list(scope),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useReturnVehicleToWork() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: ({
      breakdownId,
      resolutionNotes,
    }: {
      breakdownId: string
      resolutionNotes: string
    }) => sectorBreakdowns.returnToWork(breakdownId, resolutionNotes),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'success', message: 'تم تسجيل عودة الآلية إلى العمل وحفظ مدة التوقف' })
    },
    onError: (e) => {
      const code = e instanceof Error ? (e.message.split(':')[0] ?? '').trim() : ''
      const friendly: Record<string, string> = {
        BREAKDOWN_CONTROLLED_BY_MAINTENANCE:
          'الآلية بحالة صيانة مفتوحة الآن — تُعاد للعمل بعد إغلاق الحالة من بوابة الصيانة (الحالات المرفوضة لا تمنع العودة).',
        BREAKDOWN_RESOLUTION_NOTES_REQUIRED: 'اكتب الإجراء أو الإصلاح المنفذ (3 أحرف على الأقل).',
        BREAKDOWN_OPEN_NOT_FOUND: 'العطل غير موجود أو سبق إغلاقه أو ليس ضمن صلاحياتك.',
        SECTOR_MANAGER_FORBIDDEN: 'ليس لديك صلاحية هذه العملية.',
      }
      addToast({
        type: 'error',
        message: friendly[code] ?? handleAppError(e, { scope: 'returnVehicleToWork' }).message,
      })
    },
  })
}

export function useSubmitBreakdown() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (input: CreateBreakdownInput) => sectorBreakdowns.create(input),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'success', message: 'سُجّل بلاغ العطل وحُفظ في الأرشيف' })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'submitBreakdown' }).message }),
  })
}

/* ── الصور ── */
export function usePhotos(scope: 'active' | 'archived' = 'active') {
  return useQuery({
    queryKey: sectorKeys.photos(scope),
    queryFn: () => sectorPhotos.list(scope),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useUploadPhoto() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: ({ file, caption }: { file: File; caption: string }) =>
      sectorPhotos.upload(file, caption),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({ type: 'success', message: 'رُفعت الصورة وحُفظت' })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'uploadPhoto' }).message }),
  })
}

/* ── الحضورية ── */
export function useAttendanceByDate(date: string) {
  return useQuery({
    queryKey: sectorKeys.attendance(date),
    queryFn: () => sectorAttendance.listByDate(date),
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useSetAttendance() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (input: CreateAttendanceInput) => sectorAttendance.upsert(input),
    onSuccess: (_d, input) => {
      void qc.invalidateQueries({ queryKey: sectorKeys.all })
      addToast({
        type: 'success',
        message: input.is_present
          ? `سُجّل «${input.worker_name}» حاضرًا`
          : `سُجّل «${input.worker_name}» غائبًا`,
      })
    },
    onError: (e) =>
      addToast({ type: 'error', message: handleAppError(e, { scope: 'setAttendance' }).message }),
  })
}

/* ── ملخص الرئيسية ── */
export function useSectorSummary() {
  return useQuery({
    queryKey: sectorKeys.summary(),
    queryFn: fetchSummary,
    staleTime: API.STALE_TIME.DEFAULT,
  })
}

export function useSectorVehicleTrips() {
  return useQuery({
    queryKey: ['sector', 'vehicle-trips'],
    queryFn: () => sectorVehicleTrips.list(),
    refetchInterval: 30000,
  })
}
export function useSectorVehicleTripDays() {
  return useQuery({
    queryKey: ['sector', 'vehicle-trip-days'],
    queryFn: () => sectorVehicleTrips.days(),
    refetchInterval: 30000,
  })
}
export function useSectorVehicleTripsForDay(day: string) {
  return useQuery({
    queryKey: ['sector', 'vehicle-trips-day', day],
    queryFn: () => sectorVehicleTrips.forDay(day),
    enabled: Boolean(day),
    refetchInterval: 30000,
  })
}
function useTripStageMutation(action: 'arrival' | 'garage') {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (x: { departureId: string; notes?: string }) =>
      action === 'arrival'
        ? sectorVehicleTrips.confirmArrival(x.departureId, x.notes)
        : sectorVehicleTrips.sendToGarage(x.departureId, x.notes),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['sector', 'vehicle-trips'] })
      void qc.invalidateQueries({ queryKey: ['sector', 'vehicle-trip-days'] })
      void qc.invalidateQueries({ queryKey: ['sector', 'vehicle-trips-day'] })
      addToast({
        type: 'success',
        message:
          action === 'arrival'
            ? 'تم تأكيد وصول الآلية وإبلاغ الكراج'
            : 'تم إنهاء الوردية وإبلاغ الكراج أن الآلية في طريق العودة',
      })
    },
    onError: (e) =>
      addToast({
        type: 'error',
        message: handleAppError(e, { scope: 'sectorVehicleTrip' }).message,
      }),
  })
}
export const useConfirmSectorVehicleArrival = () => useTripStageMutation('arrival')
export const useSendSectorVehicleToGarage = () => useTripStageMutation('garage')

/** طلبات الدعم بين مسؤولي الأقسام (00154) */
const SUPPORT_KEYS = [['sector', 'support'], ['sector', 'vehicle-trips'], ['sector', 'vehicle-trips-day'], ['ops', 'support']] as const
export function useSupportRequests() {
  return useQuery({ queryKey: ['sector', 'support', 'list'], queryFn: () => sectorSupport.list(), refetchInterval: 20000 })
}
export function useSupportManagers(enabled = true) {
  return useQuery({ queryKey: ['sector', 'support', 'managers'], queryFn: () => sectorSupport.managers(), enabled })
}
export function useSupportLendableVehicles(enabled = true) {
  return useQuery({ queryKey: ['sector', 'support', 'lendable'], queryFn: () => sectorSupport.lendable(), enabled })
}
function useSupportMutation<TArgs, TOut>(fn: (a: TArgs) => Promise<TOut>, success: string) {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: fn,
    onSuccess: () => {
      SUPPORT_KEYS.forEach((k) => void qc.invalidateQueries({ queryKey: [...k] }))
      addToast({ type: 'success', message: success })
    },
    onError: (e) => addToast({ type: 'error', message: handleAppError(e, { scope: 'sectorSupport' }).message }),
  })
}
export const useCreateSupportRequest = () =>
  useSupportMutation(
    (x: { targetUserId: string; sectorId: number; neededCount: number; reason: string }) => sectorSupport.create(x),
    'أُرسل طلب الدعم إلى المسؤول المختار وأُبلغت غرفة العمليات',
  )
export const useAcceptSupportRequest = () =>
  useSupportMutation(
    (x: { requestId: string; departureIds: string[]; note?: string }) => sectorSupport.accept(x.requestId, x.departureIds, x.note),
    'تمت الموافقة وإرسال الآليات — أُبلغ المسؤول الطالب',
  )
export const useRejectSupportRequest = () =>
  useSupportMutation((x: { requestId: string; note: string }) => sectorSupport.reject(x.requestId, x.note), 'تم الاعتذار عن الطلب وإبلاغ الطالب')
export const useCancelSupportRequest = () =>
  useSupportMutation((x: { requestId: string; reason: string }) => sectorSupport.cancel(x.requestId, x.reason), 'أُلغي طلب الدعم')
export const useEndSupport = () =>
  useSupportMutation((x: { assignmentId: string; note?: string }) => sectorSupport.end(x.assignmentId, x.note), 'انتهى الدعم وعادت الآلية إلى منطقتها الأصلية')
/** تقرير غرفة العمليات لطلبات الدعم (00154) — من/إلى تواريخ بغداد */
export function useOpsSupportRequests(from: string, to: string) {
  return useQuery({
    queryKey: ['ops', 'support', from, to],
    queryFn: () =>
      sectorSupport.opsList({
        from: from ? `${from}T00:00:00+03:00` : null,
        to: to ? `${to}T23:59:59.999+03:00` : null,
        limit: 500,
      }),
    refetchInterval: 20000,
  })
}
