/** خطافات البصمة (00139) — تقني (IT) + بيانات (HR) */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { integrationsKeys } from '@lib/query-keys/integrations.keys'
import { biometric, biometricErrorMessage } from '@sdk/biometric.sdk'
import { API } from '@lib/constants/api.constants'
import { useUiStore } from '@stores/ui.store'
import type { BiometricDeviceConfig, BiometricMode, BiometricPunchFilters } from '../types'

export function useBiometricPulls(deviceId?: string | null) {
  return useQuery({
    queryKey: integrationsKeys.pulls(deviceId),
    queryFn: () => biometric.listPulls(deviceId),
    staleTime: 10_000,
  })
}

export function useBiometricPunches(filters: BiometricPunchFilters, enabled = true) {
  return useQuery({
    queryKey: integrationsKeys.punches(filters),
    queryFn: () => biometric.listPunches(filters),
    staleTime: API.STALE_TIME.DEFAULT,
    enabled,
  })
}

export function useBiometricDeviceUsers(search?: string, enabled = true) {
  return useQuery({
    queryKey: [...integrationsKeys.all, 'bio-device-users', search ?? ''] as const,
    queryFn: () => biometric.listDeviceUsers(search),
    staleTime: API.STALE_TIME.DEFAULT,
    enabled,
  })
}

function useInvalidateBiometric() {
  const qc = useQueryClient()
  return () => {
    void qc.invalidateQueries({ queryKey: integrationsKeys.devices() })
    void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-pulls'] })
    void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-punches'] })
  }
}

export function useUpdateBiometricDevice() {
  const invalidate = useInvalidateBiometric()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (v: { id: string; name?: string; mode?: BiometricMode; config?: BiometricDeviceConfig; location_hint?: string | null; timezone_offset?: string; public_url?: string | null }) =>
      biometric.updateDevice(v.id, { name: v.name, mode: v.mode, config: v.config, location_hint: v.location_hint, timezone_offset: v.timezone_offset, public_url: v.public_url }),
    onSuccess: () => { invalidate(); addToast({ type: 'success', message: 'حُفظت إعدادات المصدر' }) },
    onError: (e) => addToast({ type: 'error', message: biometricErrorMessage(e) }),
  })
}

export function useBiometricDiagnostics(deviceId: string | null, enabled = true) {
  return useQuery({
    queryKey: [...integrationsKeys.all, 'bio-diagnostics', deviceId ?? ''] as const,
    queryFn: () => biometric.diagnostics(deviceId!),
    enabled: enabled && !!deviceId,
    refetchInterval: 10_000,
  })
}

export function useRequestDeviceUsers() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (deviceId: string) => biometric.requestDeviceUsers(deviceId),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: integrationsKeys.devices() }) },
  })
}

export function useRotateBridgeKey() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (deviceId: string) => biometric.rotateBridgeKey(deviceId),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: integrationsKeys.devices() }) },
  })
}

export function useTestBiometricSource() {
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (v: { deviceId: string; from?: string; to?: string }) => biometric.testSource(v.deviceId, v.from, v.to),
    onError: (e) => addToast({ type: 'error', message: biometricErrorMessage(e) }),
  })
}

export function usePullBiometric() {
  const invalidate = useInvalidateBiometric()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (v: { deviceId: string; from?: string; to?: string }) => biometric.pull(v.deviceId, v.from, v.to),
    onSuccess: (r) => {
      invalidate()
      addToast({ type: 'success', message: `اكتمل السحب: ${r.received} مستلَم · ${r.inserted} جديد · ${r.duplicates} مكرر · ${r.unmatched} غير مطابَق` })
    },
    onError: (e) => { invalidate(); addToast({ type: 'error', message: biometricErrorMessage(e) }) },
  })
}

export function useImportBiometricPunches() {
  const invalidate = useInvalidateBiometric()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (v: { deviceId: string; logs: Array<{ pin: string; at: string; direction?: string; name?: string }>; method?: string }) =>
      biometric.importPunches(v.deviceId, v.logs, v.method),
    onSuccess: (r) => {
      invalidate()
      addToast({ type: 'success', message: `استيراد: ${r.inserted} جديد · ${r.duplicates} مكرر · ${r.unmatched} غير مطابَق` })
    },
    onError: (e) => addToast({ type: 'error', message: biometricErrorMessage(e) }),
  })
}

export function useProcessBiometricPushes() {
  const invalidate = useInvalidateBiometric()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (limit?: number) => biometric.processPushes(limit),
    onSuccess: (n) => { invalidate(); addToast({ type: 'success', message: `عولجت ${n} بصمة من دفعات ADMS إلى الدفتر` }) },
    onError: (e) => addToast({ type: 'error', message: biometricErrorMessage(e) }),
  })
}

export function useLinkBiometricPin() {
  const invalidate = useInvalidateBiometric()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (v: { pin: string; employeeId: string }) => biometric.linkPin(v.pin, v.employeeId),
    onSuccess: () => { invalidate(); addToast({ type: 'success', message: 'رُبط رقم البصمة بالموظف وحُدِّثت بصماته السابقة' }) },
    onError: (e) => addToast({ type: 'error', message: biometricErrorMessage(e) }),
  })
}

export function useDeriveAttendance() {
  const qc = useQueryClient()
  const addToast = useUiStore((s) => s.addToast)
  return useMutation({
    mutationFn: (date: string) => biometric.deriveAttendance(date),
    onSuccess: (n) => {
      void qc.invalidateQueries({ queryKey: ['attendance'] })
      addToast({ type: 'success', message: n === 0 ? 'لا بصمات مطابَقة لهذا اليوم' : `حُدِّث حضور ${n} موظفاً من البصمات` })
    },
    onError: (e) => addToast({ type: 'error', message: biometricErrorMessage(e) }),
  })
}

// ─── 00174 ───
export function useBiometricCommands(deviceId: string | null, enabled = true) {
  return useQuery({
    queryKey: [...integrationsKeys.all, 'bio-commands', deviceId ?? ''] as const,
    queryFn: () => biometric.commands(deviceId!),
    enabled: enabled && !!deviceId,
    refetchInterval: 10_000,
  })
}
function useCommandMutation<TVars>(fn: (v: TVars) => Promise<number>) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: fn,
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-commands'] })
      void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-pulls'] })
    },
  })
}
export function useQueryAttlog() {
  return useCommandMutation((v: { deviceId: string; from: string; to: string }) => biometric.queryAttlog(v.deviceId, v.from, v.to))
}
export function usePushEmployeeToDevices() {
  return useCommandMutation((v: { employeeId: string; deviceIds?: string[] | null }) => biometric.pushEmployee(v.employeeId, v.deviceIds ?? null))
}
export function usePushAllEmployees() {
  return useCommandMutation((deviceId: string) => biometric.pushAllEmployees(deviceId))
}
export function useDeleteDeviceUser() {
  return useCommandMutation((v: { deviceId: string; pin: string }) => biometric.deleteDeviceUser(v.deviceId, v.pin))
}
export function useUnregisteredDevices(enabled = true) {
  return useQuery({
    queryKey: [...integrationsKeys.all, 'bio-unregistered'] as const,
    queryFn: () => biometric.unregisteredDevices(),
    enabled,
    refetchInterval: 30_000,
  })
}
export function useAdmsEndpoints() {
  return useQuery({ queryKey: [...integrationsKeys.all, 'bio-endpoints'] as const, queryFn: () => biometric.endpoints() })
}
export function useAddAdmsEndpoint() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (input: { label: string; host: string; note?: string | null }) => biometric.addEndpoint(input),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-endpoints'] }) },
  })
}
export function useRemoveAdmsEndpoint() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => biometric.removeEndpoint(id),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-endpoints'] }) },
  })
}

export function useUnmatchedReport(f: { from: string; to: string; branchId?: string | null; search?: string | null }, enabled = true) {
  return useQuery({
    queryKey: [...integrationsKeys.all, 'bio-unmatched-report', f.from, f.to, f.branchId ?? '', f.search ?? ''] as const,
    queryFn: () => biometric.unmatchedReport(f),
    enabled: enabled && !!f.from && !!f.to && f.from <= f.to,
    staleTime: 30_000,
  })
}
export function useSetDeviceAdmin() {
  return useCommandMutation((v: { deviceId: string; pin: string; name?: string | null }) => biometric.setDeviceAdmin(v.deviceId, v.pin, v.name))
}
export function useCancelCommand() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => biometric.cancelCommand(id),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-commands'] })
      void qc.invalidateQueries({ queryKey: [...integrationsKeys.all, 'bio-pulls'] })
    },
  })
}
