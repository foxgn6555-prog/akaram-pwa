/** 00394: رمز القطاع من جدول parent_sectors (ديناميكي) */
export type ComplaintSector = string
export type InboxStatus = 'new' | 'extracting' | 'ready' | 'needs_review' | 'imported' | 'failed' | 'duplicate'
export type ComplaintItemStatus = 'under_review' | 'assigned' | 'in_progress' | 'processed' | 'quality_review' | 'approved' | 'returned'

export interface ComplaintInboxMessage {
  id: string
  senderEmail: string
  senderName: string | null
  replyTo: string | null
  subject: string | null
  bodyText: string | null
  sector: ComplaintSector | null
  receivedAt: string
  status: InboxStatus
  attachmentCount: number
  duplicateOf: string | null
}

export interface ComplaintInboxMedia {
  id: string
  mediaCode: string
  name: string
  mimeType: string
  /** '' عندما يكون الملف محذوفاً من المنصة (مؤرشف خارجياً) */
  url: string
  storagePath?: string
  duplicate: boolean
  duplicateCount: number
  itemId: string | null
}

export interface ComplaintInboxMediaPage {
  rows: ComplaintInboxMedia[]
  totalCount: number
  imageCount: number
  sortedImageCount: number
  remainingImageCount: number
}

export interface ComplaintSortEntry extends ComplaintItemFields {
  mediaId: string
}

export interface ComplaintBatchSortResult {
  complaintId: string
  itemIds: string[]
  createdCount: number
  remainingCount: number
}

export interface ComplaintItemFields {
  title?: string
  municipalCenter?: string
  neighborhood?: string
  alley?: string
  locationText?: string
  ocrText?: string
}

export interface ComplaintItem {
  id: string
  complaintId: string
  referenceNo: string
  complaintStatus: string
  sector: ComplaintSector
  sequenceNo: number
  title: string | null
  municipalCenter: string | null
  neighborhood: string | null
  alley: string | null
  locationText: string | null
  ocrText: string | null
  assignedTo: string | null
  status: ComplaintItemStatus
  managerNotes: string | null
  reviewerNotes: string | null
  receivedAt: string
  inboxMessageId: string | null
  ticketName: string
}

export interface ManagerComplaintTicket {
  complaintId: string
  referenceNo: string
  name: string
  receivedAt: string
  sector: ComplaintSector
  items: ComplaintItem[]
  types: string[]
  status: 'ready' | 'in_progress' | 'review' | 'approved' | 'returned'
}

export interface ComplaintTicketAfterUpload extends ComplaintAfterUpload {
  itemId: string
}

export interface ComplaintManager {
  userId: string
  fullName: string
  jobTitle: string | null
  /** المناطق التشغيلية (1..8) المسندة للمسؤول من ملفه؛ تُستخدم لاقتراحه من المحلة. */
  sectorIds: number[]
}

/** محلة مسجلة ضمن منطقة تشغيلية (بيانات المحلة والزقاق). */
export interface ComplaintNeighborhood {
  id: string
  sectorId: number
  sectorName: string
  parentSector: ComplaintSector
  name: string
  isActive: boolean
  usageCount: number
}

export interface SendComplaintEmailInput {
  complaintId?: string
  reportId?: string
  to: string[]
  subject: string
  text: string
  attachmentPaths: string[]
}

export interface ComplaintEmailDelivery {
  id: string
  recipients: string[]
  subject: string
  status: 'queued' | 'accepted' | 'delivered' | 'temporary_failure' | 'permanent_failure' | 'rejected'
  errorMessage: string | null
  createdAt: string
  deliveredAt: string | null
}

export interface ComplaintAfterUpload {
  file: File
  source: 'camera' | 'gallery'
}

export interface ComplaintMedia {
  id: string
  itemId: string | null
  mediaCode: string
  kind: 'before' | 'after' | 'email_attachment' | 'report'
  /** '' عندما يكون الملف محذوفاً من المنصة (مؤرشف خارجياً) */
  url: string
  storagePath?: string
  name: string
  mimeType: string
  capturedAt: string | null
  isActive: boolean
  replacementReason: string | null
  supersededAt: string | null
  displayOrder: number
}

export interface ComplaintAnalytics {
  from: string
  to: string
  sector: ComplaintSector | null
  summary: { total: number; approved: number; active: number; review: number; unassigned: number; withAfter: number }
  daily: Array<{ day: string; total: number; approved: number; review: number; active: number }>
  statuses: Array<{ status: ComplaintItemStatus; count: number }>
  sectors: Array<{ sector: ComplaintSector; count: number; approved: number }>
}

export type ComplaintReportPeriod = 'daily' | 'weekly' | 'monthly' | 'semiannual' | 'annual'

export interface ComplaintSummary {
  total: number
  newCount: number
  assigned: number
  inProgress: number
  processed: number
  archived: number
  karrada: number
  zaafaraniya: number
}

export interface ComplaintTemplate {
  id: string
  name: string
  description: string | null
  sector: ComplaintSector | null
  layout: Record<string, unknown>
  isDefault: boolean
  isActive: boolean
  version: number
}

export interface ComplaintContact {
  id: string
  sector: ComplaintSector | null
  name: string
  email: string
  kind: 'sender_rule' | 'recipient' | 'cc'
  isActive: boolean
}

export interface ComplaintArchiveFolder { id:string; inboxMessageId:string|null; subject:string; senderEmail:string; sector:ComplaintSector; archivedAt:string; restoredAt:string|null; permanentlyDeletedAt:string|null; snapshot:Record<string,unknown> }
export interface ComplaintDeletionRequest { id:string; folderId:string; reason:string; status:'pending'|'approved'|'executing'|'rejected'|'executed'|'failed'; requestedAt:string; decidedAt:string|null; decisionNote:string|null; errorMessage:string|null; attemptCount:number; executionStartedAt:string|null }

export interface ComplaintSetting {
  key: string
  value: Record<string, unknown>
  description: string | null
}

export interface ComplaintStatusEvent {
  id: string
  fromStatus: string | null
  toStatus: string
  note: string | null
  actorId: string | null
  createdAt: string
}

export interface ComplaintItemDetail {
  item: ComplaintItem
  media: ComplaintMedia[]
  history: ComplaintStatusEvent[]
  senderEmail: string | null
  subject: string | null
  bodyText: string | null
  inboxMessageId: string | null
}

export interface ComplaintReportItem {
  itemId: string
  displayOrder: number
  included: boolean
  slideLayout: Record<string, unknown>
  item: ComplaintItem
}

export interface ComplaintReportDetail extends ComplaintReport {
  layout: Record<string, unknown>
  items: ComplaintReportItem[]
  approvedAt: string | null
  sentAt: string | null
  archivedAt: string | null
  deliveries: ComplaintEmailDelivery[]
  /** 00339: سلسلة موافقات مفتوحة (null = لا سلسلة) + سبب آخر إعادة */
  approvalChainId: string | null
  approvalRequestedAt: string | null
  approvalRejectedNote: string | null
}

export interface ComplaintReport {
  id: string
  reportDate: string
  sector: ComplaintSector
  title: string
  status: 'draft' | 'quality_review' | 'approved' | 'sending' | 'sent' | 'failed' | 'archived'
  pptxPath: string | null
  recipients: string[]
  deliveryId: string | null
  createdAt: string
  scope: 'email' | 'daily'
  inboxMessageId: string | null
}

/** صف «قاعدة بيانات الشكاوى» (complaint_database_rows) — بصيغة السجل الشهري المعتمد */
export interface ComplaintDatabaseRow {
  item_id: string
  complaint_id: string
  reference_no: string
  ticket_name: string
  received_at: string
  received_date: string
  received_time: string
  sender_name: string
  municipal_center: string | null
  sector: string
  shift: string
  neighborhood: string | null
  street: string | null
  delay_type: string | null
  source: string
  handler_name: string | null
  item_status: ComplaintItemStatus
  completion: 'منجز' | 'منجز متأخر' | 'متأخر' | 'قيد المعالجة'
  hours_to_complete: number | null
  attachments: string
  attachments_count: number
  ack_confirmed: boolean
}
