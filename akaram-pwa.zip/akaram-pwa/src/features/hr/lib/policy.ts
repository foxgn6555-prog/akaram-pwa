/** منطق شرائح الاستقطاع (مشترك بين صفحة السياسة والاختبارات) */
import type { DeductionTier, ShortfallMethod } from '../types'

/** تحقق محلي للشرائح مطابق لتحقق الخادم: متتالية من 1 بلا فجوات، آخرها مفتوح، لكل شريحة دقائق أو كسر يوم */
export function validateTiers(tiers: DeductionTier[]): string | null {
  if (tiers.length === 0) return 'أضف شريحة واحدة على الأقل'
  let prev = 0
  for (let i = 0; i < tiers.length; i++) {
    const t = tiers[i]!
    if (t.from !== prev + 1) return `الشريحة ${i + 1}: يجب أن تبدأ من الدقيقة ${prev + 1}`
    if (t.to != null && t.to < t.from) return `الشريحة ${i + 1}: النهاية قبل البداية`
    if (t.to == null && i !== tiers.length - 1) return `الشريحة ${i + 1}: الشريحة المفتوحة يجب أن تكون الأخيرة`
    if ((t.minutes == null || t.minutes === 0) && (t.day_fraction == null || t.day_fraction === 0) && i > 0) return `الشريحة ${i + 1}: حدد دقائق استقطاع أو كسر يوم`
    if (t.to != null) prev = t.to
  }
  if (tiers[tiers.length - 1]!.to != null) return 'الشريحة الأخيرة يجب أن تكون مفتوحة (بلا نهاية)'
  return null
}
/** تطبيق الشرائح على نقص محدد — للمعاينة الحيّة */
export function applyTiers(tiers: DeductionTier[], shortfall: number): { minutes: number; days: number } {
  if (shortfall <= 0) return { minutes: 0, days: 0 }
  const t = tiers.find((x) => shortfall >= x.from && (x.to == null || shortfall <= x.to))
  return { minutes: t?.minutes ?? 0, days: t?.day_fraction ?? 0 }
}


/** 00196: احتساب نقص اليوم بأي طريقة (مطابق لـ app.hr_shortfall_for_rule) — السماحية يطبّقها المستدعي */
export interface ShortfallRule { shortfall_method?: ShortfallMethod; shortfall_multiplier?: number; shortfall_block_minutes?: number; deduction_tiers: DeductionTier[] }
export function applyShortfall(rule: ShortfallRule, shortfall: number, shiftMinutes = 480): { minutes: number; days: number; note: string } {
  const method = rule.shortfall_method ?? 'tiers'
  if (shortfall <= 0) return { minutes: 0, days: 0, note: '' }
  if (method === 'hour_bank') return { minutes: shortfall, days: 0, note: 'بنك الساعات: نقص اليوم بالدقيقة' }
  if (method === 'tiers') return { ...applyTiers(rule.deduction_tiers, shortfall), note: 'شريحة النقص المطابقة' }
  const mult = rule.shortfall_multiplier ?? 1
  const block = Math.max(1, rule.shortfall_block_minutes ?? 30)
  const raw = method === 'blocks' ? Math.ceil(shortfall / block) * block : shortfall
  let minutes = Math.ceil(raw * (method === 'actual' ? 1 : mult))
  let note = method === 'actual' ? 'دقيقة بدقيقة' : method === 'multiplier' ? `دقيقة بدقيقة × ${mult}` : `تقريب لأعلى إلى كتل ${block} د${mult !== 1 ? ` × ${mult}` : ''}`
  if (minutes >= Math.max(1, shiftMinutes)) { minutes = 0; note += ' (بلغ سقف اليوم الكامل)'; return { minutes, days: 1, note } }
  return { minutes, days: 0, note }
}
export const SHORTFALL_METHOD_LABEL: Record<ShortfallMethod, string> = {
  tiers: 'شرائح: نقص من..إلى ⇒ دقائق محددة أو كسر يوم',
  actual: 'دقيقة بدقيقة: يُستقطع نفس عدد دقائق النقص',
  multiplier: 'دقيقة بدقيقة × مضاعف (مثلاً ×2)',
  blocks: 'كتل زمنية: يُقرَّب النقص لأعلى إلى أقرب كتلة (مثلاً 30 د) ثم × المضاعف',
  hour_bank: 'بنك الساعات: نقص كل يوم بذاته (تأخير − بقاء بنفس اليوم + خروج مبكر) يُستقطع بالدقيقة؛ البقاء الزائد والمجيء المبكر رصيد إجازة بسقف',
}

/** 00218: بنك الساعات — قاعدة اليوم الواحد (مطابق لـ app.hr_compute_day_metrics/hr_hour_bank):
 *  نقص اليوم = max(0, تأخير فوق السماحية − بقاء بعد النهاية) + خروج مبكر − زمنية مدفوعة · فائض اليوم = شرائح(بقاء زائد) + شرائح(مجيء مبكر) (00248). لا تعويض بين الأيام. */
/** 00248: الاحتساب التدريجي بالشرائح (مطابق لـ app.hr_credit_tiered): كل جزء بنسبة شريحته، ما بعد آخر شريحة = 0، تقريب لأقرب دقيقة */
export interface CreditTierLike { upto: number; pct: number }
export const DEFAULT_EARLY_IN_TIERS: CreditTierLike[] = []
export const DEFAULT_LATE_OUT_TIERS: CreditTierLike[] = [{ upto: 720, pct: 100 }]
export function creditTiered(minutes: number, tiers: CreditTierLike[] | null | undefined): number {
  const m = Math.max(0, minutes || 0); let prev = 0, acc = 0
  for (const t of tiers ?? []) { const seg = Math.min(m, t.upto) - prev; if (seg <= 0) break; acc += (seg * t.pct) / 100; prev = t.upto }
  return Math.round(acc)
}
export function validateCreditTiers(tiers: CreditTierLike[]): string | null {
  if (tiers.length > 10) return 'الحد الأقصى 10 شرائح'
  let prev = 0
  for (const t of tiers) {
    if (!Number.isFinite(t.upto) || !Number.isFinite(t.pct)) return 'قيم غير صالحة'
    if (t.upto <= prev) return 'حدود الشرائح يجب أن تكون تصاعدية'
    if (t.upto > 720) return 'الحد الأقصى للشريحة 720 دقيقة'
    if (t.pct < 0 || t.pct > 100) return 'النسبة بين 0 و100'
    prev = t.upto
  }
  return null
}
export interface HourBankDay { required: number; lateMinutes?: number; earlyInMinutes?: number; earlyOutMinutes?: number; extraMinutes?: number; permitMinutes?: number; waived?: boolean }
export interface HourBankInput { shiftMinutes: number; creditCapDays: number; graceMinutes: number; days: HourBankDay[]; earlyInTiers?: CreditTierLike[]; lateOutTiers?: CreditTierLike[] }
export interface HourBankResult {
  requiredMinutes: number; creditedMinutes: number; netMinutes: number
  deductionMinutes: number; surplusMinutes: number; daysShort: number; creditDays: number; creditCapped: boolean
}
export function hourBankDay(d: HourBankDay, graceMinutes: number, earlyInTiers: CreditTierLike[] = DEFAULT_EARLY_IN_TIERS, lateOutTiers: CreditTierLike[] = DEFAULT_LATE_OUT_TIERS): { shortfall: number; surplus: number } {
  const lateRaw = d.lateMinutes ?? 0, late = lateRaw <= graceMinutes ? 0 : lateRaw
  const extra = d.extraMinutes ?? 0, earlyIn = d.earlyInMinutes ?? 0, earlyOut = d.earlyOutMinutes ?? 0
  const shortfall = d.waived ? 0 : Math.max(0, Math.max(0, late - extra) + earlyOut - (d.permitMinutes ?? 0))
  // 00248: البقاء يغطي تأخير اليوم 100% أولاً، ثم الزائد والمجيء المبكر كلٌّ بشرائحه
  return { shortfall, surplus: creditTiered(Math.max(0, extra - late), lateOutTiers) + creditTiered(earlyIn, earlyInTiers) }
}
export function computeHourBank(i: HourBankInput): HourBankResult {
  const shift = Math.max(1, i.shiftMinutes)
  let requiredMinutes = 0, deductionMinutes = 0, surplusMinutes = 0, daysShort = 0
  for (const d of i.days) {
    const { shortfall, surplus } = hourBankDay(d, i.graceMinutes, i.earlyInTiers ?? DEFAULT_EARLY_IN_TIERS, i.lateOutTiers ?? DEFAULT_LATE_OUT_TIERS)
    requiredMinutes += d.required; deductionMinutes += shortfall; surplusMinutes += surplus; if (shortfall > 0) daysShort += 1
  }
  const rawDays = Math.round((surplusMinutes / shift) * 1000) / 1000
  return {
    requiredMinutes, creditedMinutes: requiredMinutes - deductionMinutes + surplusMinutes, netMinutes: surplusMinutes - deductionMinutes,
    deductionMinutes, surplusMinutes, daysShort, creditDays: Math.min(rawDays, i.creditCapDays), creditCapped: rawDays > i.creditCapDays,
  }
}