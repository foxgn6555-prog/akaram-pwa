/** تصدير كشف الرواتب الشهري (المالية) إلى Excel احترافي — RTL، ترويسة، مجاميع، تنسيق أرقام */
import type { Borders, Worksheet } from 'exceljs'
import type { AttendanceDeduction, PayrollReconcileRow, PayrollSheetRow } from '../types'
import { explainRow, groupByBranchDept, RECONCILE_ISSUE_LABELS, reconcileSummary, rowFlags, sheetTotals } from './payrollSheetModel'

/** 00194 — خيارات التصدير: تسمية الفلاتر المطبّقة، صفوف التحقق الحسابي، ورقة لكل فرع */
export interface PayrollExcelOptions { filtersLabel?: string; reconcile?: PayrollReconcileRow[]; branchSheets?: boolean }

const CONTRACT: Record<string, string> = { monthly: 'شهري', daily: 'أجر يومي' }

export interface DeptGroup { name: string; rows: PayrollSheetRow[]; present: number; absent: number; ops: number; auto: number; proposed: number; final: number; gross: number; deductions: number }
/** مفتاح الترتيب الطبيعي للرقم الوظيفي (PF-2 قبل PF-9 قبل PF-10) — مطابق لـ app.hr_employee_sort_key في القاعدة */
export function employeeSortKey(num: string | null | undefined): string {
  const digits = (num ?? '').replace(/\D/g, '') || '0'
  return `${digits.padStart(20, '0')}|${num ?? ''}`
}
/** إجمالي الراتب قبل الاستقطاع (يُحتسب محلياً للصفوف المصدَّرة قبل 00184) */
export function rowGross(r: PayrollSheetRow): number {
  if (r.gross_amount != null) return r.gross_amount
  if (r.pay_type == null) return 0
  if (r.pay_type === 'daily') return (r.daily_rate ?? 0) * (r.payable_days ?? r.days_present + (r.days_leave_paid ?? 0)) + (r.allowances_total ?? 0)
  return (r.base_salary ?? 0) + (r.allowances_total ?? 0)
}
/** إجمالي الاستقطاعات = الإجمالي − الصافي المقترح (أو العمود المخزَّن) */
export function rowDeductions(r: PayrollSheetRow): number {
  if (r.deductions_total != null) return r.deductions_total
  if (r.pay_type == null) return 0
  return Math.max(0, rowGross(r) - (r.proposed_net ?? 0))
}
/** تجميع صفوف الكشف حسب القسم (الأقسام أبجدياً، «بلا قسم» آخراً؛ داخل القسم بالرقم الوظيفي ثم الاسم) مع مجاميع فرعية */
export function groupByDepartment(rows: PayrollSheetRow[]): DeptGroup[] {
  const map = new Map<string, PayrollSheetRow[]>()
  for (const r of rows) { const k = r.department_name ?? 'بلا قسم'; map.set(k, [...(map.get(k) ?? []), r]) }
  const names = [...map.keys()].sort((a, b) => (a === 'بلا قسم' ? 1 : b === 'بلا قسم' ? -1 : a.localeCompare(b, 'ar')))
  return names.map((name) => {
    const g = (map.get(name) ?? []).slice().sort((a, b) => employeeSortKey(a.employee_number).localeCompare(employeeSortKey(b.employee_number)) || (a.full_name ?? '').localeCompare(b.full_name ?? '', 'ar'))
    const sum = (f: (r: PayrollSheetRow) => number) => g.reduce((s, r) => s + (f(r) || 0), 0)
    return { name, rows: g, present: sum((r) => r.days_present), absent: sum((r) => r.days_absent), ops: sum((r) => r.ops_deduction_amount + (r.ops_deduction_days_amount ?? 0)), auto: sum((r) => r.auto_deduction_amount ?? 0), proposed: sum((r) => r.proposed_net ?? 0), final: sum((r) => r.final_net ?? r.proposed_net ?? 0), gross: sum(rowGross), deductions: sum(rowDeductions) }
  })
}


export function payrollFileName(month: string) { return `كشف-الرواتب-${month.slice(0, 7)}.xlsx` }

export async function buildPayrollWorkbook(month: string, rows: PayrollSheetRow[], deductions: AttendanceDeduction[] = [], opts: PayrollExcelOptions = {}) {
  const ExcelJS = await import('exceljs')
  const wb = new ExcelJS.Workbook()
  wb.creator = 'شركة جزيرة الأكارم — الشؤون المالية'; wb.created = new Date()
  const approved = rows[0]?.export_status === 'approved'
  const ws = wb.addWorksheet(`رواتب ${month.slice(0, 7)}`, { views: [{ rightToLeft: true, state: 'frozen', xSplit: 3, ySplit: 4 }], pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 } })
  writePayrollTable(ws, rows, {
    title: `كشف رواتب شهر ${month.slice(0, 7)} — ${approved ? 'معتمد ومقفل' : 'مسودة قبل الاعتماد'}`,
    subtitle: `الإصدار ${rows[0]?.export_version ?? '-'} · صُدّر من غرفة العمليات في ${rows[0] ? new Date(rows[0].exported_at).toLocaleString('ar-IQ-u-nu-latn') : '-'} · أُنشئ ${new Date().toLocaleString('ar-IQ-u-nu-latn')} · العملة: دينار عراقي${opts.filtersLabel ? ` · ${opts.filtersLabel}` : ''}`,
    approved,
  })
  // 00195 · ورقة «تفاصيل الحضور»: كل أرقام الحضور والاستقطاع التلقائي (مجدول/محتسب/تأخير/نقص/قاعدة الاستقطاع) خارج الكشف الرئيسي
  const as = wb.addWorksheet('تفاصيل الحضور', { views: [{ rightToLeft: true, state: 'frozen', xSplit: 3, ySplit: 4 }], pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 } })
  writeAttendanceDetail(as, rows, { title: `تفاصيل الحضور والاستقطاع التلقائي — ${month.slice(0, 7)}`, subtitle: 'ورقة تدقيق: أساس أرقام الكشف الرئيسي كما استلمتها المالية من غرفة العمليات — لا تُستعمل للصرف', approved })

  // ورقة 2: ملخص الأقسام — عدد الموظفين، حاضر/غائب، استقطاعات، صافي مقترح/معتمد
  const ds = wb.addWorksheet('ملخص الأقسام', { views: [{ rightToLeft: true, state: 'frozen', ySplit: 2 }] })
  const dh = ['القسم', 'عدد الموظفين', 'أيام حاضر', 'أيام غائب', 'الإجمالي', 'استقطاع العمليات', 'استقطاع تلقائي', 'إجمالي الاستقطاعات', 'الصافي المقترح', 'الصافي المعتمد']
  ds.mergeCells(1, 1, 1, dh.length); ds.getCell('A1').value = `ملخص الأقسام — ${month.slice(0, 7)}`; ds.getCell('A1').font = { bold: true, size: 14 }; ds.getCell('A1').alignment = { horizontal: 'center' }
  const dhr = ds.getRow(2); dhr.values = dh
  dhr.eachCell((c) => { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF334155' } }; c.alignment = { horizontal: 'center' }; c.border = thin() })
  const groups = groupByDepartment(rows)
  groups.forEach((g) => { const r = ds.addRow([g.name, g.rows.length, g.present, g.absent, g.gross, g.ops, g.auto, g.deductions, g.proposed, g.final]); r.eachCell((c, col) => { c.border = thin(); c.alignment = { horizontal: col === 1 ? 'right' : 'center' }; if (col >= 5) c.numFmt = '#,##0' }) })
  const gsum = (f: (g: DeptGroup) => number) => groups.reduce((s, g) => s + f(g), 0)
  const dt = ds.addRow(['الإجمالي', rows.length, gsum((g) => g.present), gsum((g) => g.absent), gsum((g) => g.gross), gsum((g) => g.ops), gsum((g) => g.auto), gsum((g) => g.deductions), gsum((g) => g.proposed), gsum((g) => g.final)])
  dt.eachCell((c, col) => { c.font = { bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } }; c.border = thin(); if (col >= 5) c.numFmt = '#,##0' })
  ;[22, 12, 10, 10, 16, 16, 16, 16, 16, 16].forEach((w, i) => { ds.getColumn(i + 1).width = w })

  // ورقة 3 (00185): تفاصيل استقطاعات غرفة العمليات — صف لكل استقطاع مع مرجع الكشف المعتمد إن وُجد
  if (deductions.length > 0) {
    const xs = wb.addWorksheet('تفاصيل الاستقطاعات', { views: [{ rightToLeft: true, state: 'frozen', ySplit: 2 }] })
    const xh = ['ت', 'الرقم الوظيفي', 'الموظف', 'النوع', 'المبلغ', 'الأيام', 'السبب', 'المصدر', 'رقم الكشف', 'التاريخ']
    xs.mergeCells(1, 1, 1, xh.length); xs.getCell('A1').value = `استقطاعات غرفة العمليات — ${month.slice(0, 7)} (يدوية + كشوفات معتمدة)`; xs.getCell('A1').font = { bold: true, size: 14 }; xs.getCell('A1').alignment = { horizontal: 'center' }
    const xhr = xs.getRow(2); xhr.values = xh
    xhr.eachCell((c) => { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF334155' } }; c.alignment = { horizontal: 'center' }; c.border = thin() })
    const sorted = deductions.slice().sort((a, b) => employeeSortKey(a.employees?.employee_number).localeCompare(employeeSortKey(b.employees?.employee_number)) || a.created_at.localeCompare(b.created_at))
    sorted.forEach((d, i) => {
      const r = xs.addRow([i + 1, d.employees?.employee_number ?? '', d.employees?.full_name ?? '', d.days > 0 ? 'أيام' : 'مبلغ', d.amount, d.days, d.reason, d.source_disclosure_id ? 'كشف معتمد' : 'يدوي (غرفة العمليات)', d.disclosure?.ref_no ?? '', d.created_at.slice(0, 10)])
      r.eachCell((c, col) => { c.border = thin(); c.alignment = { horizontal: col === 3 || col === 7 ? 'right' : 'center', wrapText: col === 7 }; if (col === 5) c.numFmt = '#,##0' })
    })
    const xt = xs.addRow(['', '', 'الإجمالي', '', deductions.length ? { formula: `SUM(E3:E${2 + deductions.length})`, result: 0 } : 0, deductions.length ? { formula: `SUM(F3:F${2 + deductions.length})`, result: 0 } : 0])
    xt.eachCell((c, col) => { c.font = { bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } }; c.border = thin(); if (col === 5) c.numFmt = '#,##0' })
    ;[5, 12, 26, 8, 13, 8, 40, 16, 14, 12].forEach((w, i) => { xs.getColumn(i + 1).width = w })
  }

  // 00194 · ورقة «ملخص الفروع»: فرع ← أقسامه، مع مجاميع كل مستوى وعدد بلا ملف راتب
  const bs = wb.addWorksheet('ملخص الفروع', { views: [{ rightToLeft: true, state: 'frozen', ySplit: 2 }] })
  const bh = ['الفرع / القسم', 'عدد الموظفين', 'بلا ملف راتب', 'أيام حاضر', 'أيام غائب', 'الإجمالي', 'ثابتة', 'استقطاع العمليات', 'استقطاع تلقائي', 'أقساط السلف', 'إجمالي الاستقطاعات', 'الصافي المقترح', 'الصافي المعتمد']
  bs.mergeCells(1, 1, 1, bh.length); bs.getCell('A1').value = `ملخص الفروع والأقسام — ${month.slice(0, 7)}`; bs.getCell('A1').font = { bold: true, size: 14 }; bs.getCell('A1').alignment = { horizontal: 'center' }
  const bhr = bs.getRow(2); bhr.values = bh
  bhr.eachCell((c) => { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF334155' } }; c.alignment = { horizontal: 'center', wrapText: true }; c.border = thin() })
  const tRow = (label: string, t: ReturnType<typeof sheetTotals>) => [label, t.count, t.missing, t.present, t.absent, t.gross, t.fixed, t.ops, t.auto, t.advance, t.deductions, t.proposed, t.final]
  const branches = groupByBranchDept(rows)
  branches.forEach((b) => {
    const br = bs.addRow(tRow(b.branch, b.totals)); br.eachCell((c, col) => { c.font = { bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0F2FE' } }; c.border = thin(); c.alignment = { horizontal: col === 1 ? 'right' : 'center' }; if (col >= 6) c.numFmt = '#,##0' })
    b.departments.forEach((d) => { const dr = bs.addRow(tRow(`    ${d.name}`, d.totals)); dr.eachCell((c, col) => { c.border = thin(); c.alignment = { horizontal: col === 1 ? 'right' : 'center' }; if (col >= 6) c.numFmt = '#,##0' }) })
  })
  const all = sheetTotals(rows)
  const bt = bs.addRow(tRow('الإجمالي العام', all)); bt.eachCell((c, col) => { c.font = { bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } }; c.border = thin(); if (col >= 6) c.numFmt = '#,##0' })
  ;[28, 12, 12, 10, 10, 16, 14, 16, 16, 14, 18, 16, 16].forEach((w, i) => { bs.getColumn(i + 1).width = w })

  // 00194 · ورقة لكل فرع (عند أكثر من فرع) بنفس أعمدة الكشف الرئيسي
  if (opts.branchSheets !== false && branches.length > 1) {
    branches.forEach((b) => {
      const name = `فرع · ${b.branch}`.replace(/[\\/?*[\]:]/g, ' ').slice(0, 31)
      const bws = wb.addWorksheet(name, { views: [{ rightToLeft: true, state: 'frozen', xSplit: 3, ySplit: 4 }], pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 } })
      writePayrollTable(bws, b.rows, { title: `كشف رواتب ${month.slice(0, 7)} — ${b.branch}`, subtitle: `${b.rows.length} موظفاً · ${b.departments.length} قسماً`, approved })
    })
  }

  // 00194 · ورقة «التحقق الحسابي»: القيم المخزَّنة مقابل المُعاد احتسابها + المخالفات + شرح المعادلة
  if (opts.reconcile && opts.reconcile.length > 0) {
    const rc = opts.reconcile; const sum = reconcileSummary(rc)
    const vs = wb.addWorksheet('التحقق الحسابي', { views: [{ rightToLeft: true, state: 'frozen', ySplit: 3 }] })
    const vh = ['ت', 'الرقم الوظيفي', 'الاسم', 'الفرع', 'القسم', 'الإجمالي (مخزَّن)', 'الإجمالي (محسوب)', 'الاستقطاعات (مخزَّنة)', 'الاستقطاعات (محسوبة)', 'الصافي (مخزَّن)', 'الصافي (محسوب)', 'الصافي المعتمد', 'فرق الصافي', 'النتيجة', 'الملاحظات', 'شرح المعادلة']
    vs.mergeCells(1, 1, 1, vh.length); vs.getCell('A1').value = `التحقق الحسابي لكشف ${month.slice(0, 7)} — ${sum.money === 0 ? 'كل الأرقام متطابقة ✓' : `${sum.money} صف غير متطابق ✗`}`
    vs.getCell('A1').font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } }; vs.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: sum.money === 0 ? 'FF065F46' : 'FFB91C1C' } }; vs.getCell('A1').alignment = { horizontal: 'center' }
    vs.mergeCells(2, 1, 2, vh.length); vs.getCell('A2').value = `${sum.total} صف · متطابق كلياً ${sum.ok} · مخالفات مالية ${sum.money} · فروق حضورية بعد التصدير ${sum.attendance} · بلا ملف راتب ${sum.missing}`; vs.getCell('A2').alignment = { horizontal: 'center' }
    const vhr = vs.getRow(3); vhr.values = vh
    vhr.eachCell((c) => { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF334155' } }; c.alignment = { horizontal: 'center', wrapText: true }; c.border = thin() })
    rc.forEach((r, i) => {
      const diff = r.net_expected != null && r.net_stored != null ? Math.round((r.net_stored - r.net_expected) * 100) / 100 : null
      const row = vs.addRow([i + 1, r.employee_number ?? '', r.full_name ?? '', r.branch_name ?? '', r.department_name ?? '', r.gross_stored ?? '', r.gross_expected ?? '', r.deductions_stored ?? '', r.deductions_expected ?? '', r.net_stored ?? '', r.net_expected ?? '', r.final_net ?? '', diff ?? '',
        r.ok ? '✓ متطابق' : r.money_ok ? '⚠ تنبيه' : '✗ غير متطابق', r.issues.map((k) => RECONCILE_ISSUE_LABELS[k] ?? k).join(' · '), explainRow(r)])
      row.eachCell((c, col) => { c.border = thin(); c.alignment = { horizontal: col <= 5 || col >= 15 ? 'right' : 'center', vertical: 'middle', wrapText: col >= 15 }; if (col >= 6 && col <= 13) c.numFmt = '#,##0.##' })
      row.getCell(14).font = { bold: true, color: { argb: r.ok ? 'FF065F46' : r.money_ok ? 'FFB45309' : 'FFB91C1C' } }
      if (!r.money_ok) row.getCell(14).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } }
    })
    ;[5, 12, 24, 14, 16, 14, 14, 14, 14, 14, 14, 14, 10, 14, 36, 90].forEach((w, i) => { vs.getColumn(i + 1).width = w })
  }
  return wb
}

interface TableMeta { title: string; subtitle: string; approved: boolean }
/** 00195 — أعمدة الورقة الرئيسية المبسّطة (المالية تحتاج الصافي؛ تفاصيل الحضور في ورقة «تفاصيل الحضور») */
export const MAIN_HEADERS = ['ت', 'الرقم الوظيفي', 'الاسم', 'القسم', 'الفرع', 'العنوان الوظيفي', 'نوع التعاقد',
  'الأيام المدفوعة', 'غائب', 'الراتب الأساسي / أجر اليوم', 'المخصصات', 'الإجمالي المستحق',
  'استقطاعات ثابتة', 'استقطاع غرفة العمليات', 'استقطاع تلقائي', 'قاعدة الاستقطاع التلقائي', 'قسط السلفة', 'ضريبة آلية مؤجرة', 'إجمالي الاستقطاعات', 'ساعات العمل الإضافي',
  'الصافي المقترح', 'الصافي المعتمد', 'ملاحظة المالية', 'تحقق الصافي', 'ملاحظات التدقيق'] as const
/** 00251: العمود 18 = ضريبة الآلية المؤجرة (3٪ افتراضياً من الإجمالي المستحق — سطر مستقل) · 00353: العمود 20 = ساعات العمل الإضافي (يُضاف إلى الصافي، لا ضريبة) */
export const MAIN_COL = { gross: 12, rented_tax: 18, deductions: 19, overtime: 20, proposed: 21, final: 22, verify: 24, notes: 25 } as const
const MAIN_MONEY = [10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22]
/** الجدول الرئيسي للكشف (الورقة الأولى وأوراق الفروع): ترويسة، صف لكل موظف، عمود تحقق بمعادلة Excel، مجاميع بمعادلات */
function writePayrollTable(ws: Worksheet, rows: PayrollSheetRow[], meta: TableMeta) {
  const headers = [...MAIN_HEADERS]
  writeTitle(ws, headers, meta)
  rows.forEach((r, i) => {
    const paidLeave = r.days_leave_paid ?? r.days_leave
    // 00201: الأيام المستحقة المخزّنة (يومي أو نموذج الأيام المستحقة) وإلا حضور + إجازة مدفوعة
    const paidDays = r.payable_days ?? r.days_present + paidLeave
    const row = ws.addRow([i + 1, r.employee_number, r.full_name, r.department_name, r.branch_name, r.job_title, CONTRACT[r.pay_type ?? r.contract_type ?? ''] ?? '—',
      paidDays, r.days_absent, r.pay_type === 'daily' ? r.daily_rate ?? 0 : r.base_salary ?? 0, r.allowances_total ?? 0, rowGross(r),
      r.fixed_deductions_total ?? 0, r.ops_deduction_amount + (r.ops_deduction_days_amount ?? 0), r.auto_deduction_amount ?? 0, r.auto_deduction_rule ?? (r.auto_deduction_basis === 'disabled' ? 'متوقف' : ''), r.advance_installment ?? 0, r.rented_tax_amount ?? 0, rowDeductions(r), r.overtime_amount ?? 0,
      r.proposed_net ?? 0, r.final_net ?? r.proposed_net ?? 0, r.finance_note ?? '', '', rowFlags(r).join(' · ')])
    const n = row.number
    // تحقق بمعادلة حية داخل Excel: الصافي المقترح = max(0, الإجمالي − إجمالي الاستقطاعات) + ساعات العمل الإضافي (00353) — يبقى صحيحاً حتى لو عدّل المحاسب الخلايا
    row.getCell(MAIN_COL.verify).value = r.pay_type == null ? 'بلا راتب' : { formula: `IF(ABS(MAX(0,L${n}-S${n})+T${n}-U${n})<=1,"✓","✗")`, result: '✓' }
    if ((r.overtime_amount ?? 0) > 0) row.getCell(MAIN_COL.overtime).note = `${Math.round(((r.overtime_paid_minutes ?? 0) / 60) * 100) / 100} ساعة عمل إضافي صرفها معاون المدير المفوض — تُضاف إلى الصافي ولا تدخل الإجمالي (لا ضريبة)`
    if ((r.rented_tax_amount ?? 0) > 0) row.getCell(MAIN_COL.rented_tax).note = `${r.rented_tax_pct ?? 0}٪ من الإجمالي المستحق${r.rented_tax_vehicle ? ` — ${r.rented_tax_vehicle}` : ''}${r.rented_tax_source === 'custom' ? ' (نسبة خاصة بقرار المعاون)' : ''}`
    row.eachCell({ includeEmpty: true }, (c, col) => { c.border = thin(); c.alignment = { horizontal: col <= 7 || col === 16 || col === 23 || col === 25 ? 'right' : 'center', vertical: 'middle', wrapText: col === 23 || col === 25 }; if (MAIN_MONEY.includes(col)) c.numFmt = '#,##0'; if (i % 2) c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } } })
    row.getCell(MAIN_COL.gross).font = { bold: true }; row.getCell(MAIN_COL.deductions).font = { bold: true, color: { argb: 'FFB91C1C' } }; row.getCell(MAIN_COL.final).font = { bold: true }
    if (r.final_net != null && r.final_net !== r.proposed_net) row.getCell(MAIN_COL.final).font = { bold: true, color: { argb: 'FFB45309' } }
    if (r.pay_type == null) row.getCell(MAIN_COL.proposed).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEF3C7' } }
    if (rowFlags(r).length) row.getCell(MAIN_COL.notes).font = { color: { argb: 'FFB45309' } }
  })
  const first = 5, last = 4 + rows.length
  const tot = ws.addRow(['', '', 'الإجمالي'])
  ;[8, 9, ...MAIN_MONEY].forEach((col) => { tot.getCell(col).value = rows.length ? { formula: `SUM(${colL(col)}${first}:${colL(col)}${last})`, result: 0 } : 0; if (MAIN_MONEY.includes(col)) tot.getCell(col).numFmt = '#,##0' })
  tot.getCell(MAIN_COL.verify).value = rows.length ? { formula: `IF(COUNTIF(X${first}:X${last},"✗")=0,"✓ كل الصفوف متطابقة",COUNTIF(X${first}:X${last},"✗")&" صف غير متطابق")`, result: '✓' } : ''
  tot.eachCell((c) => { c.font = { bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } }; c.border = thin() })
  const widths = [5, 12, 26, 16, 14, 16, 10, 9, 7, 15, 12, 15, 13, 14, 13, 18, 12, 13, 15, 14, 15, 15, 24, 12, 30]
  widths.forEach((w, i) => { ws.getColumn(i + 1).width = w })
  ws.autoFilter = { from: { row: 4, column: 1 }, to: { row: last, column: headers.length } }
}

/** 00195 — ورقة «تفاصيل الحضور»: كل أرقام الحضور والاستقطاع التلقائي التي كانت تزحم الكشف الرئيسي (للتدقيق لا للصرف) */
export const DETAIL_HEADERS = ['ت', 'الرقم الوظيفي', 'الاسم', 'القسم', 'الفرع', 'نوع التعاقد',
  'أيام مجدولة', 'أيام محتسبة', 'غير محتسب', 'حاضر', 'متأخر', 'غائب', 'بصمة ناقصة', 'إجازة مدفوعة', 'إجازة غير مدفوعة', 'دقائق التأخير', 'الأيام المدفوعة',
  'الفترة المشمولة', 'أيام مشمولة / أيام الشهر', 'أجر اليوم المحتسب',
  'استقطاع العمليات (مبلغ)', 'استقطاع العمليات (أيام)', 'استقطاع العمليات (مبلغ الأيام)', 'أسباب استقطاعات العمليات',
  'قاعدة الاستقطاع التلقائي', 'أساس المبلغ', 'استقطاع تلقائي (دقائق)', 'استقطاع تلقائي (أيام)', 'منها أيام غياب/إجازة غير مدفوعة', 'منها أيام شرائح النقص', 'استقطاع تلقائي (مبلغ)', 'مقيّد بسقف', 'الصافي المقترح'] as const
function writeAttendanceDetail(ws: Worksheet, rows: PayrollSheetRow[], meta: TableMeta) {
  const headers = [...DETAIL_HEADERS,
  'بنك الساعات: المطلوب (د)', 'بنك الساعات: المعمول (د)', 'بنك الساعات: الصافي (د)', 'بنك الساعات: رصيد إجازة (يوم)']
  writeTitle(ws, headers, meta)
  const BASIS: Record<string, string> = { salary: 'من الراتب', fixed: 'مبالغ ثابتة', disabled: 'متوقف' }
  rows.forEach((r, i) => {
    const paidLeave = r.days_leave_paid ?? r.days_leave, unpaidLeave = r.days_leave_unpaid ?? 0
    const row = ws.addRow([i + 1, r.employee_number, r.full_name, r.department_name, r.branch_name, CONTRACT[r.pay_type ?? r.contract_type ?? ''] ?? '—',
      r.scheduled_days ?? r.working_days, r.working_days, r.unevaluated_days ?? 0, r.days_present, r.days_late, r.days_absent, r.days_incomplete, paidLeave, unpaidLeave, r.late_minutes, r.pay_type === 'daily' ? (r.payable_days ?? r.days_present + paidLeave) : r.days_present + paidLeave,
      r.period_from && r.period_to ? `${r.period_from} → ${r.period_to}` : '', r.covered_days != null && r.days_in_month != null ? `${r.covered_days} / ${r.days_in_month}` : '', r.day_rate ?? (r.pay_type === 'daily' ? r.daily_rate ?? 0 : Math.round(((r.base_salary ?? 0) / 30) * 100) / 100),
      r.ops_deduction_amount, r.ops_deduction_days, r.ops_deduction_days_amount ?? 0, r.ops_deduction_reasons ?? '',
      r.auto_deduction_rule ?? '', BASIS[r.auto_deduction_basis ?? ''] ?? '', r.auto_deduction_minutes ?? 0, r.auto_deduction_days ?? 0, r.auto_absence_days ?? 0, r.auto_shortfall_days ?? 0, r.auto_deduction_amount ?? 0,
      r.auto_deduction_capped || r.auto_deduction_days_capped ? 'نعم' : '', r.proposed_net ?? 0,
      // 00245 — بنك الساعات (فارغ عندما لا تكون الطريقة مفعّلة للموظف)
      r.hour_bank_enabled ? r.hour_bank_required_minutes ?? 0 : '', r.hour_bank_enabled ? r.hour_bank_credited_minutes ?? 0 : '', r.hour_bank_enabled ? r.hour_bank_net_minutes ?? 0 : '', r.hour_bank_enabled ? Number(r.hour_bank_credit_days ?? 0) : ''])
    row.eachCell({ includeEmpty: true }, (c, col) => { c.border = thin(); c.alignment = { horizontal: col <= 6 || col === 24 || col === 25 ? 'right' : 'center', vertical: 'middle', wrapText: col === 24 }; if ([21, 23, 31, 33].includes(col)) c.numFmt = '#,##0'; if (col === 20) c.numFmt = '#,##0.##'; if (i % 2) c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } } })
    if ((r.unevaluated_days ?? 0) > 0) row.getCell(9).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } }
  })
  const first = 5, last = 4 + rows.length
  const tot = ws.addRow(['', '', 'الإجمالي'])
  ;[7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 21, 22, 23, 27, 28, 29, 30, 31, 33].forEach((col) => { tot.getCell(col).value = rows.length ? { formula: `SUM(${colL(col)}${first}:${colL(col)}${last})`, result: 0 } : 0; if ([21, 23, 31, 33].includes(col)) tot.getCell(col).numFmt = '#,##0' })
  tot.eachCell((c) => { c.font = { bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } }; c.border = thin() })
  const widths = [5, 12, 26, 16, 14, 10, 8, 8, 8, 7, 7, 7, 8, 9, 9, 9, 9, 24, 12, 12, 13, 11, 13, 34, 18, 12, 10, 10, 11, 10, 13, 9, 14]
  widths.forEach((w, i) => { ws.getColumn(i + 1).width = w })
  ws.autoFilter = { from: { row: 4, column: 1 }, to: { row: last, column: headers.length } }
}
function writeTitle(ws: Worksheet, headers: string[], meta: TableMeta) {
  const width = headers.length
  ws.mergeCells(1, 1, 1, width)
  ws.getCell('A1').value = meta.title
  ws.getCell('A1').font = { bold: true, size: 16, color: { argb: 'FFFFFFFF' } }
  ws.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: meta.approved ? 'FF065F46' : 'FF1E3A8A' } }
  ws.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' }; ws.getRow(1).height = 30
  ws.mergeCells(2, 1, 2, width)
  ws.getCell('A2').value = meta.subtitle
  ws.getCell('A2').alignment = { horizontal: 'center' }; ws.getCell('A2').font = { size: 10, color: { argb: 'FF475569' } }
  ws.getRow(3).height = 6
  const hr = ws.getRow(4); hr.values = headers
  hr.eachCell((c) => { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF334155' } }; c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; c.border = thin() })
  hr.height = 32
}

export async function downloadPayrollExcel(month: string, rows: PayrollSheetRow[], deductions: AttendanceDeduction[] = [], opts: PayrollExcelOptions = {}) {
  const wb = await buildPayrollWorkbook(month, rows, deductions, opts)
  const buf = await wb.xlsx.writeBuffer()
  const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = payrollFileName(month); a.click(); URL.revokeObjectURL(url)
}

function thin(): Partial<Borders> { const s = { style: 'thin' as const, color: { argb: 'FFCBD5E1' } }; return { top: s, bottom: s, left: s, right: s } }
function colL(n: number) { let s = ''; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26) } return s }
