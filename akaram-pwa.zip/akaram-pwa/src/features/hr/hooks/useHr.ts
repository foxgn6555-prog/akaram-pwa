/** خطافات الموارد البشرية (00142) — HR + غرفة العمليات + المالية */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { hrKeys } from '@lib/query-keys/hr.keys'
import { departmentsKeys } from '@lib/query-keys/departments.keys'
import { hr, hrErrorMessage } from '@sdk/hr.sdk'
import { useUiStore } from '@stores/ui.store'
import type { AttendanceFilters, BehaviorPeriodKind, DeputyDeductionKind, CreateEmployeeInput, DocType, EmployeeDocument, HrHireRequestStatusFilter, HrPolicy, HrShift, ImportEmployeeRow, LeaveRequestInput, LeaveType, TerminationType } from '../types'

function useToast() {
  const addToast = useUiStore((s) => s.addToast)
  return {
    ok: (message: string) => addToast({ type: 'success', message }),
    err: (e: unknown) => addToast({ type: 'error', message: hrErrorMessage(e) }),
  }
}

// ── الشفتات ──
export function useHrShifts(includeInactive = false) {
  return useQuery({ queryKey: [...hrKeys.shifts(), includeInactive], queryFn: () => hr.listShifts(includeInactive), staleTime: 60_000 })
}
export function useSaveShift() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: Partial<HrShift> & Pick<HrShift, 'name' | 'start_time' | 'end_time'>) => hr.saveShift(v),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.shifts() }); t.ok('حُفظ الشفت') },
    onError: t.err,
  })
}
export function useShiftAssignments(employeeId: string) {
  return useQuery({ queryKey: hrKeys.assignments(employeeId), queryFn: () => hr.listAssignments(employeeId), enabled: !!employeeId })
}
export function useAssignShift() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: hr.assignShift,
    onSuccess: (_d, v) => {
      void qc.invalidateQueries({ queryKey: hrKeys.assignments(v.employeeId) })
      void qc.invalidateQueries({ queryKey: hrKeys.employee(v.employeeId) })
      void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'employees'] })
      t.ok('حُدّث شفت الموظف')
    },
    onError: t.err,
  })
}

// ── الموظفون ──
export function useHrEmployees(f: Parameters<typeof hr.listEmployees>[0] = {}) {
  return useQuery({ queryKey: hrKeys.employees(f), queryFn: () => hr.listEmployees(f), staleTime: 15_000 })
}
export function useHrEmployee(id: string | undefined) {
  return useQuery({ queryKey: hrKeys.employee(id ?? ''), queryFn: () => hr.getEmployee(id!), enabled: !!id })
}
export function useCreateEmployee() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: CreateEmployeeInput) => hr.createEmployee(v),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('سُجّل الموظف وأُرسل ملف راتبه إلى المالية') },
    onError: t.err,
  })
}
/* ─── 00348 (B): طلبات التعيين المعتمدة ─── */
export function useHrHireRequests(status: HrHireRequestStatusFilter = 'approved') {
  return useQuery({ queryKey: hrKeys.hireRequests(status), queryFn: () => hr.hireRequests(status), staleTime: 15_000 })
}
export function useEmployeeNumberAvailable(number: string) {
  const n = number.trim()
  return useQuery({ queryKey: hrKeys.employeeNumberCheck(n), queryFn: () => hr.employeeNumberAvailable(n), enabled: n.length > 0, staleTime: 5_000 })
}
export function useCompleteHireRequest() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { requestId: string; input: CreateEmployeeInput }) => hr.completeHireRequest(v.requestId, v.input),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('نزل الموظف للنظام وأُرسل ملف راتبه إلى المالية وأُبلغ مقدّم الطلب') },
    onError: t.err,
  })
}
export function useUpdateEmployee() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { id: string; patch: Record<string, unknown> }) => hr.updateEmployee(v.id, v.patch),
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.employee(v.id) }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'employees'] }); t.ok('حُفظت بيانات الموظف') },
    onError: t.err,
  })
}
export function useTerminateEmployee() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { id: string; type: TerminationType; lastDay: string; reason: string; attachmentPath?: string | null }) => hr.terminateEmployee(v),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('أُنهيت الخدمة وأُبلغت المالية للتسوية') },
    onError: t.err,
  })
}

// ── المستمسكات ──
export function useEmployeeDocuments(employeeId: string) {
  return useQuery({ queryKey: hrKeys.documents(employeeId), queryFn: () => hr.listDocuments(employeeId), enabled: !!employeeId })
}
export function useManagerCandidates(employeeId: string, q: string, enabled = true) {
  return useQuery({ queryKey: [...hrKeys.employee(employeeId), 'manager-candidates', q], queryFn: () => hr.managerCandidates(employeeId, q), enabled: enabled && !!employeeId, staleTime: 15_000 })
}
export function useUploadDocument() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { employeeId: string; docType: DocType; file: File; title?: string }) => hr.uploadDocument(v.employeeId, v.docType, v.file, v.title),
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.documents(v.employeeId) }); void qc.invalidateQueries({ queryKey: hrKeys.employee(v.employeeId) }); t.ok('رُفع المستمسك') },
    onError: t.err,
  })
}
// 00389-أ
export function useSetDocumentDates() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { doc: EmployeeDocument; issuedOn: string | null; expiresOn: string | null }) => hr.setDocumentDates(v.doc.id, v.issuedOn, v.expiresOn),
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.documents(v.doc.employee_id) }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'documents-expiring'] }); void qc.invalidateQueries({ queryKey: hrKeys.documentsExpirySummary() }); t.ok('حُفظت تواريخ الوثيقة') },
    onError: t.err,
  })
}
export function useExpiringDocuments(withinDays: number | null, departmentId: string, search: string) {
  return useQuery({ queryKey: hrKeys.documentsExpiring(withinDays, departmentId, search), queryFn: () => hr.documentsExpiring(withinDays, departmentId || null, search || null), staleTime: 30_000 })
}
export function useNowBoard(branchId: string, departmentId: string, search: string) {
  return useQuery({ queryKey: hrKeys.nowBoard(branchId, departmentId, search), queryFn: () => hr.nowBoard(branchId || null, departmentId || null, search || null), refetchInterval: 30_000, staleTime: 10_000 })
}
export function useDocumentsExpirySummary() {
  return useQuery({ queryKey: hrKeys.documentsExpirySummary(), queryFn: hr.documentsExpirySummary, staleTime: 30_000 })
}
export function useDocumentsExpiryRunNow() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: hr.documentsExpiryRunNow, onSuccess: (n) => { void qc.invalidateQueries({ queryKey: ['notifications'] }); t.ok(`فُحصت ${n} وثيقة وأُرسلت التنبيهات اللازمة`) }, onError: t.err })
}
export function useDeleteDocument() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: hr.deleteDocument,
    onSuccess: (_d, doc) => { void qc.invalidateQueries({ queryKey: hrKeys.documents(doc.employee_id) }); t.ok('حُذف المستمسك') },
    onError: t.err,
  })
}

// ── الإجازات ──
export function useHrLeaves(f: Parameters<typeof hr.listLeaves>[0]) {
  return useQuery({ queryKey: hrKeys.leaves(f), queryFn: () => hr.listLeaves(f) })
}

// ── الحضور ──
export function useAttendance(f: AttendanceFilters, enabled = true) {
  return useQuery({ queryKey: hrKeys.attendance(f), queryFn: () => hr.listAttendance(f), enabled, staleTime: 10_000 })
}
export function useEvaluateAttendance() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { from: string; to: string; employeeId?: string | null }) => hr.evaluateAttendance(v.from, v.to, v.employeeId),
    onSuccess: (n) => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'attendance'] }); void qc.invalidateQueries({ queryKey: hrKeys.dashboard() }); t.ok(`أُعيد احتساب ${n} يوم/موظف من البصمات`) },
    onError: t.err,
  })
}
export function useHrDashboard() {
  return useQuery({ queryKey: hrKeys.dashboard(), queryFn: hr.dashboard, staleTime: 30_000 })
}

// ── غرفة العمليات ──
export function useEditAttendance() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: hr.editAttendance,
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'attendance'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'audit'] }); t.ok('حُفظ التعديل وسُجّل في سجل التدقيق') },
    onError: t.err,
  })
}
export function useResetAttendance() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { employeeId: string; date: string; reason: string }) => hr.resetAttendance(v.employeeId, v.date, v.reason),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'attendance'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'audit'] }); t.ok('أُعيد الصف إلى الاحتساب التلقائي') },
    onError: t.err,
  })
}
export function useDeductions(month: string, employeeId?: string | null) {
  return useQuery({ queryKey: hrKeys.deductions(month, employeeId), queryFn: () => hr.listDeductions(month, employeeId), enabled: !!month })
}
export function useEmployeeMonthDays(employeeId: string | null, month: string) {
  return useQuery({ queryKey: ['hr', 'month-days', employeeId, month], queryFn: () => hr.employeeMonthDays(employeeId as string, month), enabled: !!employeeId })
}
export function useAttendanceAuditNamed(f: Parameters<typeof hr.listAuditNamed>[0] = {}) {
  return useQuery({ queryKey: [...hrKeys.audit(f), 'named'], queryFn: () => hr.listAuditNamed(f) })
}
export function useAttendanceAudit(f: Parameters<typeof hr.listAudit>[0] = {}) {
  return useQuery({ queryKey: hrKeys.audit(f), queryFn: () => hr.listAudit(f) })
}
export function useMonthExports(month?: string) {
  return useQuery({ queryKey: hrKeys.exports(month), queryFn: () => hr.listExports(month) })
}
export function useExportRows(exportId: string | null | undefined) {
  return useQuery({ queryKey: hrKeys.exportRows(exportId ?? ''), queryFn: () => hr.exportRows(exportId!), enabled: !!exportId })
}
export function useExportMonth() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (month: string) => hr.exportMonth(month),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'exports'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'export-status'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'audit'] }); t.ok('صُدّرت بيانات الشهر إلى معاون المدير المفوض — تصل المالية بعد اعتماده') },
    onError: t.err,
  })
}

// ── 00193: الحضوريات بمرحلتين ──
export function useAttendanceGrid(f: { month: string; branchId?: string | null; departmentId?: string | null; search?: string | null }, enabled = true) {
  return useQuery({ queryKey: [...hrKeys.all, 'grid', f], queryFn: () => hr.monthGrid(f), enabled: enabled && !!f.month })
}
export function useHourBankMonth(month: string, enabled = true) {
  return useQuery({ queryKey: [...hrKeys.all, 'hour-bank', month], queryFn: () => hr.hourBankMonth(month), enabled: enabled && !!month })
}
export function useAttendanceConfirmation(month: string) {
  return useQuery({ queryKey: [...hrKeys.all, 'confirmation', month], queryFn: () => hr.attendanceConfirmation(month), enabled: !!month })
}
export function useConfirmAttendanceMonth() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (month: string) => hr.confirmAttendanceMonth(month),
    onSuccess: (c) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(c.confirm_count > 1 ? 'أُعيد اعتماد حضورية الشهر' : 'اعتُمدت حضورية الشهر — انتقل إلى الكشف المعتمد') },
    onError: t.err,
  })
}
export function useReopenAttendanceMonth() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { month: string; reason: string }) => hr.reopenAttendanceMonth(v.month, v.reason),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('أُعيد فتح حضورية الشهر — بُلّغت وحدة التطوير المركزية') },
    onError: t.err,
  })
}

// ── المالية ──
export function usePayrollSheet(month: string) {
  return useQuery({ queryKey: hrKeys.payrollSheet(month), queryFn: () => hr.payrollSheet(month), enabled: !!month })
}
/** 00194 */
export function usePayrollReconcile(month: string, enabled = true) {
  return useQuery({ queryKey: [...hrKeys.payrollSheet(month), 'reconcile'], queryFn: () => hr.payrollReconcile(month), enabled: !!month && enabled })
}
export function useAdjustPayroll() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { rowId: string; finalNet: number; note: string }) => hr.adjustPayroll(v.rowId, v.finalNet, v.note),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'payroll-sheet'] }); t.ok('حُفظ التعديل') },
    onError: t.err,
  })
}
/** 00186 — احتساب الشهر كاملاً */
export function useEvaluateMonth() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (month: string) => hr.evaluateMonth(month),
    onSuccess: (n) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(`اكتمل احتساب الشهر — ${n} يوم/موظف`) },
    onError: t.err,
  })
}
/** 00247 — بوابة المالية (بانتظار معاون المدير المفوض؟) */
export function usePayrollGate(month: string) {
  return useQuery({ queryKey: [...hrKeys.all, 'payroll-gate', month], queryFn: () => hr.payrollGate(month), enabled: !!month })
}
/** 00247 — وحدة معاون المدير المفوض */
export function useDeputyMonths() {
  return useQuery({ queryKey: [...hrKeys.all, 'deputy-months'], queryFn: () => hr.deputyMonths() })
}
export function useDeputyReview(month: string, enabled = true) {
  return useQuery({ queryKey: [...hrKeys.all, 'deputy-review', month], queryFn: () => hr.deputyReview(month), enabled: enabled && !!month })
}
export function useDeputyAudit(exportId: string | null | undefined) {
  return useQuery({ queryKey: [...hrKeys.all, 'deputy-audit', exportId], queryFn: () => hr.deputyAudit(exportId as string), enabled: !!exportId })
}
export function useDeputyAdjust() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { rowId: string; kind: DeputyDeductionKind; mode: 'waive' | 'amount' | 'clear'; amount?: number | null; reason?: string | null }) => hr.deputyAdjust(v.rowId, v.kind, v.mode, v.amount ?? null, v.reason ?? null),
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(v.mode === 'clear' ? 'أُلغي التخفيف' : v.mode === 'waive' ? 'تم الإعفاء الكامل' : 'تم تعديل المبلغ') },
    onError: t.err,
  })
}
export function useDeputyEmployeeWaive() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { rowId: string; reason: string | null }) => (v.reason == null ? hr.deputyEmployeeRestore(v.rowId) : hr.deputyEmployeeWaive(v.rowId, v.reason)),
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(v.reason == null ? 'أُلغي الإعفاء الكلي وعادت استقطاعات الموظف' : 'أُعفي الموظف من كل استقطاعات الشهر') },
    onError: t.err,
  })
}
export function useDeputyPercent() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { exportId: string; pct: number; reason: string }) => hr.deputyPercent(v.exportId, v.pct, v.reason),
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(v.pct > 0 ? `طُبّق تخفيض ${v.pct}% على الجميع` : 'أُلغي التخفيض العام') },
    onError: t.err,
  })
}
export function useDeputyApprove() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (exportId: string) => hr.deputyApprove(exportId),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('اعتُمدت الاستقطاعات وأُرسل الكشف إلى المالية') },
    onError: t.err,
  })
}
// 00353 — الساعات الإضافية المدفوعة (المعاون)
export function useOvertimeOverview(month: string) { return useQuery({ queryKey: [...hrKeys.all, 'overtime', month], queryFn: () => hr.overtimeOverview(month), staleTime: 15_000 }) }
export function useOvertimeDays(employeeId: string | null, month: string) { return useQuery({ queryKey: [...hrKeys.all, 'overtime-days', employeeId, month], queryFn: () => hr.overtimeDays(employeeId as string, month), enabled: !!employeeId }) }
export function useOvertimeRates(enabled: boolean) { return useQuery({ queryKey: [...hrKeys.all, 'overtime-rates'], queryFn: () => hr.overtimeRates(), enabled }) }
export function useOvertimeHistory(enabled: boolean) { return useQuery({ queryKey: [...hrKeys.all, 'overtime-history'], queryFn: () => hr.overtimeHistory(200), enabled }) }
export function useOvertimePay() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { employeeId: string; month: string; note: string | null }) => hr.overtimePay(v.employeeId, v.month, v.note), onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('صُرفت الساعات — ستظهر سطراً مستقلاً في كشف الرواتب') }, onError: t.err })
}
export function useOvertimeReject() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { employeeId: string; month: string; note: string }) => hr.overtimeReject(v.employeeId, v.month, v.note), onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('سُجّل الرفض') }, onError: t.err })
}
export function useOvertimeCancel() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { payoutId: string; note: string }) => hr.overtimeCancel(v.payoutId, v.note), onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('أُلغي القرار — عاد الموظف إلى «بانتظار القرار»') }, onError: t.err })
}
export function useOvertimeMemberEvents(enabled: boolean) { return useQuery({ queryKey: [...hrKeys.all, 'overtime-member-events'], queryFn: () => hr.overtimeMemberEvents(200), enabled }) }
export function useOvertimeMemberSet() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { employeeId: string; active: boolean; note: string | null }) => hr.overtimeMemberSet(v.employeeId, v.active, v.note), onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(v.active ? 'أُدرج الموظف — ساعاته تُصرف نقداً من الآن' : 'أُزيل الموظف — يعود إلى رصيد الإجازات') }, onError: t.err })
}
export function useOvertimeRateSet() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { employeeId: string; enabled: boolean; amount: number; note: string | null }) => hr.overtimeRateSet(v.employeeId, v.enabled, v.amount, v.note), onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(v.enabled ? 'حُفظ أجر الساعة الثابت' : 'أُلغي الأجر الثابت — يُحسب من الراتب') }, onError: t.err })
}
// 00251 — ضريبة الآليات المؤجرة
export function useRentedTaxOverview() { return useQuery({ queryKey: [...hrKeys.all, 'rented-tax'], queryFn: () => hr.rentedTaxOverview(), staleTime: 30_000 }) }
export function useRentedTaxAudit(enabled: boolean) { return useQuery({ queryKey: [...hrKeys.all, 'rented-tax-audit'], queryFn: () => hr.rentedTaxAudit(200), enabled }) }
export function useRentedTaxPreview(month: string | null) { return useQuery({ queryKey: [...hrKeys.all, 'rented-tax-preview', month], queryFn: () => hr.rentedTaxPreview(month as string), enabled: !!month }) }
export function useRentedTaxSetPct() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { pct: number; reason: string }) => hr.rentedTaxSetPct(v.pct, v.reason), onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('حُدّثت النسبة العامة — تسري على التصدير القادم') }, onError: t.err })
}
export function useRentedTaxOverrideSet() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { employeeId: string; mode: 'exempt' | 'custom'; pct: number | null; reason: string; validTo: string | null }) => hr.rentedTaxOverrideSet(v.employeeId, v.mode, v.pct, v.reason, v.validTo), onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(v.mode === 'exempt' ? 'سُجّل الإعفاء' : 'سُجّلت النسبة الخاصة') }, onError: t.err })
}
export function useRentedTaxOverrideClear() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { employeeId: string; reason: string }) => hr.rentedTaxOverrideClear(v.employeeId, v.reason), onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('أُلغي الاستثناء — يعود للنسبة العامة') }, onError: t.err })
}
export function useDeputyReopen() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { exportId: string; reason: string }) => hr.deputyReopen(v.exportId, v.reason),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('أُعيد فتح المراجعة — الكشف محجوب عن المالية') },
    onError: t.err,
  })
}
/** 00185 — حالة آخر تصدير للشهر (التغييرات بعده) */
export function useMonthExportStatus(month: string) {
  return useQuery({ queryKey: [...hrKeys.all, 'export-status', month], queryFn: () => hr.monthExportStatus(month), enabled: !!month })
}
/** 00185 — استقطاعات موظف في شهر مع مرجع الكشف */
export function useEmployeeMonthDeductions(employeeId: string | null, month: string) {
  return useQuery({ queryKey: ['hr', 'month-deductions', employeeId, month], queryFn: () => hr.employeeMonthDeductions(employeeId as string, month), enabled: !!employeeId })
}
export function useApprovePayroll() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: string | { exportId: string; force?: boolean; discardMissingDraft?: boolean }) => typeof v === 'string' ? hr.approvePayroll(v) : v.discardMissingDraft ? hr.approvePayrollDiscardMissingDraft(v.exportId, v.force ?? false) : hr.approvePayroll(v.exportId, v.force ?? false),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('اعتُمدت رواتب الشهر وأُقفل') },
    onError: t.err,
  })
}
export function useSalaryProfile(employeeId: string | null | undefined) {
  return useQuery({ queryKey: hrKeys.salaryProfile(employeeId ?? ''), queryFn: () => hr.getSalaryProfile(employeeId!), enabled: !!employeeId })
}
export function useSetSalary() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: hr.setSalary,
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.salaryProfile(v.employeeId) }); void qc.invalidateQueries({ queryKey: hrKeys.notices() }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'employees'] }); /* 00256: تعريف الراتب يحدّث صف الموظف في كشف الشهر المفتوح تلقائياً */ void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'payroll-sheet'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'export-status'] }); t.ok('حُفظ ملف الراتب — تحدّث كشف الشهر المفتوح تلقائياً') },
    onError: t.err,
  })
}
export function useFinanceNotices() {
  return useQuery({ queryKey: hrKeys.notices(), queryFn: hr.listNotices, staleTime: 15_000 })
}
export function useMarkNoticeDone() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (id: string) => hr.markNoticeDone(id),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.notices() }); t.ok('أُغلق الإشعار') },
    onError: t.err,
  })
}

// ─── 00143 ───
export function useImportEmployees() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { rows: ImportEmployeeRow[]; dryRun: boolean }) => hr.importEmployees(v.rows, v.dryRun),
    onSuccess: (res) => { if (!res.dry_run) { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(`استُورد ${res.ok} موظفاً${res.failed ? ` · رُفض ${res.failed}` : ''}`) } },
    onError: t.err,
  })
}
export function useHrDepartments() {
  return useQuery({ queryKey: hrKeys.departments(), queryFn: hr.listDepartments })
}
/** 00153: المسميات الوظيفية من الهيكل */
export function useHrJobTitles(includeInactive = false) {
  return useQuery({ queryKey: [...hrKeys.departments(), 'job-titles', includeInactive], queryFn: () => hr.listJobTitles(includeInactive) })
}
export function useSaveDepartment() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: hr.saveDepartment,
    onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.departments() }); void qc.invalidateQueries({ queryKey: departmentsKeys.all }); t.ok('حُفظ القسم') },
    onError: t.err,
  })
}

// ─── 00144: السياسة · الإجازات · الأرصدة · التنبيهات ───
const invalidateLeaves = (qc: ReturnType<typeof useQueryClient>) => {
  for (const k of ['leave-requests', 'balance', 'ledger', 'leaves', 'attendance', 'alerts', 'leaves-dashboard']) void qc.invalidateQueries({ queryKey: [...hrKeys.all, k] })
}
export function useHrPolicy() {
  return useQuery({ queryKey: hrKeys.policy(), queryFn: hr.policy, staleTime: 60_000 })
}
export function useSetHrPolicy() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (patch: Partial<HrPolicy>) => hr.setPolicy(patch),
    onSuccess: (p) => { qc.setQueryData(hrKeys.policy(), p); t.ok('حُفظت السياسة') },
    onError: t.err,
  })
}
export function useLeaveTypes(includeInactive = false) {
  return useQuery({ queryKey: hrKeys.leaveTypes(includeInactive), queryFn: () => hr.listLeaveTypes(includeInactive), staleTime: 60_000 })
}
export function useSaveLeaveType() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: Partial<LeaveType>) => hr.saveLeaveType(v),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'leave-types'] }); t.ok('حُفظ نوع الإجازة') },
    onError: t.err,
  })
}
export function useLeaveBalance(employeeId: string | null | undefined, year?: number | null) {
  return useQuery({ queryKey: hrKeys.balance(employeeId ?? '', year), queryFn: () => hr.balance(employeeId!, year), enabled: !!employeeId, staleTime: 15_000 })
}
export function useLeaveLedger(employeeId: string | null | undefined, year?: number | null) {
  return useQuery({ queryKey: hrKeys.ledger(employeeId ?? '', year), queryFn: () => hr.ledger(employeeId!, year), enabled: !!employeeId })
}
export function useSetGrant() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { employeeId: string; year: number; days: number; note?: string | null }) => hr.setGrant(v.employeeId, v.year, v.days, v.note),
    onSuccess: () => { invalidateLeaves(qc); t.ok('حُدّث الرصيد السنوي') },
    onError: t.err,
  })
}
export function useAdjustBalance() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { employeeId: string; year: number; days: number; reason: string }) => hr.adjustBalance(v.employeeId, v.year, v.days, v.reason),
    onSuccess: () => { invalidateLeaves(qc); t.ok('سُجّل التعديل على الرصيد') },
    onError: t.err,
  })
}
export function useLeaveRequests(f: Parameters<typeof hr.listLeaveRequests>[0], enabled = true) {
  return useQuery({ queryKey: hrKeys.leaveRequests(f), queryFn: () => hr.listLeaveRequests(f), enabled, staleTime: 10_000 })
}
export function useRequestLeave() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: LeaveRequestInput) => hr.requestLeave(v),
    onSuccess: () => { invalidateLeaves(qc); t.ok('أُرسل الطلب إلى المدير المباشر') },
    onError: t.err,
  })
}
/** 00239: غرفة العمليات — ملخص طلبات الإجازة + بحث الموظف (كل الملاك) */
export function useOpsLeavesSummary() {
  return useQuery({ queryKey: hrKeys.opsLeavesSummary(), queryFn: hr.opsLeavesSummary, staleTime: 15_000 })
}
export function useOpsLeaveEmployeeLookup(q: string) {
  return useQuery({ queryKey: hrKeys.opsLeaveLookup(q), queryFn: () => hr.opsLeaveEmployeeLookup(q), enabled: q.trim().length >= 2, staleTime: 30_000 })
}
export function useDecideLeave() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { id: string; approve: boolean; note?: string | null }) => hr.decideLeave(v.id, v.approve, v.note),
    onSuccess: (_d, v) => { invalidateLeaves(qc); t.ok(v.approve ? 'تمت الموافقة على الطلب' : 'رُفض الطلب') },
    onError: t.err,
  })
}
export function useCancelLeave() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { id: string; reason?: string | null }) => hr.cancelLeave(v.id, v.reason),
    onSuccess: () => { invalidateLeaves(qc); t.ok('أُلغي الطلب') },
    onError: t.err,
  })
}
export function useWaiveDeduction() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (v: { employeeId: string; date: string; waive: boolean; reason: string }) => hr.waiveDeduction(v.employeeId, v.date, v.waive, v.reason),
    onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'attendance'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'audit'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'alerts'] }); t.ok(v.waive ? 'أُلغي الاستقطاع المقترح وسُجّل السبب' : 'أُعيد الاستقطاع المقترح') },
    onError: t.err,
  })
}
export function useHrAlerts(month?: string | null, onlyOpen = true) {
  return useQuery({ queryKey: hrKeys.alerts(month, onlyOpen), queryFn: () => hr.listAlerts(month, onlyOpen), staleTime: 15_000 })
}
export function useAckAlert() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({
    mutationFn: (id: string) => hr.ackAlert(id),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'alerts'] }); void qc.invalidateQueries({ queryKey: hrKeys.leavesDashboard() }); t.ok('تم الإقرار بالتنبيه') },
    onError: t.err,
  })
}
export function useLeavesDashboard() {
  return useQuery({ queryKey: hrKeys.leavesDashboard(), queryFn: hr.leavesDashboard, staleTime: 30_000 })
}
export function useMyEmployee() {
  return useQuery({ queryKey: hrKeys.me(), queryFn: hr.myEmployee, staleTime: 5 * 60_000 })
}

// ─── 00195: وحدة الاستقطاعات التلقائية (التطوير المركزية) ───
const DED = [...hrKeys.all, 'deduction-rules'] as const
const invalidateDeductionUnit = (qc: ReturnType<typeof useQueryClient>) => {
  void qc.invalidateQueries({ queryKey: DED })
  for (const k of ['policy', 'attendance', 'attendance-grid', 'month-days', 'month-deductions']) void qc.invalidateQueries({ queryKey: [...hrKeys.all, k] })
}
export function useDeductionRules() {
  return useQuery({ queryKey: [...DED, 'rules'], queryFn: hr.deductionRules, staleTime: 30_000 })
}
export function useBehaviorReport(f: { kind: BehaviorPeriodKind; anchor: string; departmentId?: string | null; branchId?: string | null }) {
  return useQuery({ queryKey: [...hrKeys.all, 'behavior', f.kind, f.anchor, f.departmentId ?? '', f.branchId ?? ''], queryFn: () => hr.behaviorReport(f), staleTime: 60_000 })
}
export function useBehaviorEmployee(employeeId: string | null, kind: BehaviorPeriodKind, anchor: string) {
  return useQuery({ queryKey: [...hrKeys.all, 'behavior-employee', employeeId, kind, anchor], queryFn: () => hr.behaviorEmployee(employeeId!, kind, anchor), enabled: !!employeeId, staleTime: 60_000 })
}
export function useBehaviorSeries(f: { kind: BehaviorPeriodKind; anchor: string; count: number; departmentId?: string | null; branchId?: string | null }, enabled = true) {
  return useQuery({ queryKey: [...hrKeys.all, 'behavior-series', f.kind, f.anchor, f.count, f.departmentId ?? '', f.branchId ?? ''], queryFn: () => hr.behaviorSeries(f), enabled, staleTime: 60_000 })
}
export function useCreditTiers() {
  return useQuery({ queryKey: [...DED, 'credit-tiers'], queryFn: hr.creditTiers, staleTime: 30_000 })
}
export function useSetCreditTiers() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: hr.setCreditTiers, onSuccess: () => { invalidateDeductionUnit(qc); t.ok('حُفظت شرائح الاحتساب وأُعيد احتساب الشهر الجاري والسابق') }, onError: t.err })
}
export function useSaveDeductionRule() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: hr.saveDeductionRule, onSuccess: () => { invalidateDeductionUnit(qc); t.ok('حُفظت القاعدة وأُعيد احتساب الشهر الجاري') }, onError: t.err })
}
export function useDeleteDeductionRule() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: hr.deleteDeductionRule, onSuccess: () => { invalidateDeductionUnit(qc); t.ok('حُذفت القاعدة — موظفوها عادوا إلى القاعدة الأعم') }, onError: t.err })
}
export function useSetDeductionTargets() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: Parameters<typeof hr.setDeductionTargets>) => hr.setDeductionTargets(...v), onSuccess: () => { invalidateDeductionUnit(qc); t.ok('حُفظ نطاق القاعدة') }, onError: t.err })
}
export function useDeductionExemptions() {
  return useQuery({ queryKey: [...DED, 'exemptions'], queryFn: hr.deductionExemptions, staleTime: 30_000 })
}
export function useAddDeductionExemption() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: hr.addDeductionExemption, onSuccess: () => { invalidateDeductionUnit(qc); t.ok('أُضيف الاستثناء') }, onError: t.err })
}
export function useRemoveDeductionExemption() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: hr.removeDeductionExemption, onSuccess: () => { invalidateDeductionUnit(qc); t.ok('أُلغي الاستثناء') }, onError: t.err })
}
export function useDeductionEmployees(f: Parameters<typeof hr.deductionEmployees>[0] = {}, enabled = true) {
  return useQuery({ queryKey: [...DED, 'employees', f], queryFn: () => hr.deductionEmployees(f), enabled, staleTime: 15_000 })
}
export function useSimulateDeductionV2() {
  const t = useToast()
  return useMutation({ mutationFn: hr.simulateDeductionV2, onError: t.err })
}
export function useSimulateDeduction() {
  const t = useToast()
  return useMutation({ mutationFn: hr.simulateDeduction, onError: t.err })
}
export function useDeductionAudit(limit = 200) {
  return useQuery({ queryKey: [...DED, 'audit', limit], queryFn: () => hr.deductionAudit(limit), staleTime: 15_000 })
}

// 00355 — المنتهية خدماتهم والتصفية النهائية (المالية)
export function useSettlementsList(status: string | null, q: string | null) { return useQuery({ queryKey: [...hrKeys.all, 'settlements', status ?? '', q ?? ''], queryFn: () => hr.settlementsList(status, q, 300) }) }
export function useSettlementsSummary() { return useQuery({ queryKey: [...hrKeys.all, 'settlements-summary'], queryFn: () => hr.settlementsSummary() }) }
export function useSettlement(id: string | null) { return useQuery({ queryKey: [...hrKeys.all, 'settlement', id ?? ''], queryFn: () => hr.settlementGet(id as string), enabled: !!id }) }
export function useSettlementRecompute() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (id: string) => hr.settlementRecompute(id), onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('أُعيد احتساب البنود بآخر البيانات') }, onError: t.err })
}
export function useSettlementApprove() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { id: string; note: string | null }) => hr.settlementApprove(v.id, v.note), onSuccess: (d) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(d.status === 'debt_open' ? 'اعتُمدت التصفية — الصافي سالب فسُجّل ذمةً على الموظف' : 'اعتُمدت التصفية وجُمّدت بنودها — بانتظار التسليم') }, onError: t.err })
}
export function useSettlementDeliver() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { id: string; note: string | null }) => hr.settlementDeliver(v.id, v.note), onSuccess: () => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok('أُكّد التسليم وأُقفلت السلف المشمولة') }, onError: t.err })
}
export function useSettlementDebtClose() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { id: string; mode: 'paid' | 'waived'; note: string | null }) => hr.settlementDebtClose(v.id, v.mode, v.note), onSuccess: (_d, v) => { void qc.invalidateQueries({ queryKey: hrKeys.all }); t.ok(v.mode === 'paid' ? 'سُجّل تسديد الذمة' : 'سُجّل الإعفاء من الذمة') }, onError: t.err })
}

// 00356 — الكتب الرسمية
export function useLettersList(kind: string | null, year: number | null, q: string | null, limit = 300) { return useQuery({ queryKey: [...hrKeys.all, 'letters', kind ?? '', year ?? 0, q ?? '', limit], queryFn: () => hr.lettersList(kind, year, q, limit) }) }
export function useLetter(id: string | null) { return useQuery({ queryKey: [...hrKeys.all, 'letter', id ?? ''], queryFn: () => hr.letterGet(id as string), enabled: !!id }) }
export function useLettersForSource(sourceKind: string, sourceId: string | null) { return useQuery({ queryKey: [...hrKeys.all, 'letters-src', sourceKind, sourceId ?? ''], queryFn: () => hr.lettersForSource(sourceKind, sourceId as string), enabled: !!sourceId }) }
export function useLetterIssueDisciplinary() {
  const qc = useQueryClient(); const t = useToast()
  return useMutation({ mutationFn: (v: { employeeId: string; kind: 'notice' | 'warning'; reason: string }) => hr.letterIssueDisciplinary(v.employeeId, v.kind, v.reason), onSuccess: (d) => { void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'letters'] }); void qc.invalidateQueries({ queryKey: [...hrKeys.all, 'letters-years'] }); t.ok(`صدر كتاب ${d.kind_label} بالعدد ${d.ref} وأُبلغ الموظف والمدير المباشر`) }, onError: t.err })
}
export function useLettersYears() { return useQuery({ queryKey: [...hrKeys.all, 'letters-years'], queryFn: () => hr.lettersYears() }) }
