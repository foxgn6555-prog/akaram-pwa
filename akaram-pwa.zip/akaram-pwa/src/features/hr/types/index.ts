/** mirror لـ 00142 — منظومة الموارد البشرية (الشفتات/الموظف الكامل/الحضور/التدقيق/التصدير/الرواتب) */

export interface HrShift {
  id: string
  name: string
  start_time: string   // 'HH:MM:SS'
  end_time: string
  grace_minutes: number
  work_days: number[]  // 0=الأحد … 6=السبت
  is_active: boolean
  kind: 'fixed' | 'flexible'        // 00215: مرن = دخول بأي وقت داخل النافذة بلا تأخير
  required_hours: number | null     // 00215: الساعات المطلوبة للمرن (افتراضي 12)
}

export interface ShiftAssignment {
  id: string
  employee_id: string
  shift_id: string
  effective_from: string
  start_override: string | null
  end_override: string | null
  grace_override: number | null
  days_override: number[] | null
  note: string | null
  created_at: string
}

export type ContractType = 'monthly' | 'daily'
export type EmploymentStatus = 'active' | 'on_leave' | 'suspended' | 'terminated'
export type TerminationType = 'resignation' | 'dismissal' | 'contract_end' | 'retirement' | 'death'
export type DocType = 'photo' | 'national_id_front' | 'national_id_back' | 'residence_front' | 'residence_back' | 'driving_license' | 'contract' | 'health_cert' | 'passport' | 'other'

export interface HrEmployeeRow {
  id: string
  employee_number: string
  full_name: string
  job_title: string | null
  job_title_id?: string | null
  is_driver?: boolean
  phone: string | null
  department_id: string | null
  department_name: string | null
  branch_id: string | null
  branch_name: string | null
  employment_status: EmploymentStatus
  contract_type: ContractType
  hire_date: string
  terminated_at: string | null
  biometric_pin: string | null
  photo_path: string | null
  shift_id: string | null
  shift_name: string | null
  /** حالة الراتب فقط — الأرقام للمالية حصراً */
  salary_status: 'pending' | 'defined'
}

export interface HrEmployeeFull extends HrEmployeeRow {
  email: string | null
  phone2: string | null
  manager_id: string | null
  /** 00390: اسم المدير المباشر (مشتق من قائمة الموظفين) */
  manager_name?: string | null
  mother_name: string | null
  gender: 'male' | 'female' | null
  birth_date: string | null
  birth_place: string | null
  marital_status: 'single' | 'married' | 'divorced' | 'widowed' | null
  education: string | null
  national_id_number: string | null
  residence_card_number: string | null
  governorate: string | null
  address: string | null
  emergency_contact_name: string | null
  emergency_contact_phone: string | null
  blood_type: string | null
  termination_type: TerminationType | null
  termination_reason: string | null
  termination_attachment_path: string | null
}

export interface EmployeeDocument {
  id: string
  employee_id: string
  doc_type: DocType
  title: string | null
  storage_path: string
  mime_type: string | null
  size_bytes: number | null
  created_at: string
  /** 00389-أ */
  issued_on?: string | null
  expires_on?: string | null
}
/** 00389-أ: صف في لوحة «وثائق تنتهي» */
export interface ExpiringDocument {
  id: string; employee_id: string; employee_number: string | null; full_name: string; department_id: string | null; department_name: string | null
  doc_type: DocType; title: string | null; issued_on: string | null; expires_on: string; days_left: number; status: 'expired' | 'soon' | 'ok'
}
/** 00389-ب: «من في الدوام الآن» */
export type NowState = 'missing' | 'absent' | 'late' | 'incomplete' | 'present' | 'done' | 'upcoming' | 'leave' | 'rest' | 'off'
export interface NowBoardRow {
  employee_id: string; employee_number: string | null; full_name: string; job_title: string | null; department_id: string | null; department_name: string | null; branch_name: string | null
  shift_name: string | null; expected_in: string | null; expected_out: string | null; check_in: string | null; check_out: string | null; late_minutes: number; state: NowState; leave_type: string | null
}
export const NOW_STATE_ORDER: NowState[] = ['missing', 'absent', 'late', 'incomplete', 'present', 'done', 'upcoming', 'leave', 'rest', 'off']
export const NOW_STATE_LABELS: Record<NowState, string> = {
  missing: 'لم يحضر بعد', absent: 'غائب', late: 'حاضر متأخرًا', incomplete: 'بصمة ناقصة', present: 'حاضر', done: 'أكمل الدوام',
  upcoming: 'قبل الدوام', leave: 'في إجازة', rest: 'يوم راحة', off: 'بلا شفت',
}
export interface DocumentsExpirySummary { expired: number; soon: number; d60: number; d90: number; alert_days: number }

export interface CreateEmployeeInput {
  employee_number: string
  full_name: string
  contract_type: ContractType
  hire_date: string
  department_id?: string | null
  branch_id?: string | null
  manager_id?: string | null
  /** 00153: المسمى من الهيكل التنظيمي — لا نص حر */
  job_title_id?: string | null
  phone?: string
  phone2?: string
  email?: string
  mother_name?: string
  gender?: 'male' | 'female' | ''
  birth_date?: string
  birth_place?: string
  marital_status?: string
  education?: string
  national_id_number?: string
  residence_card_number?: string
  governorate?: string
  address?: string
  emergency_contact_name?: string
  emergency_contact_phone?: string
  blood_type?: string
  biometric_pin?: string
  shift_id?: string | null
  shift_start_override?: string
  shift_end_override?: string
  shift_grace_override?: number | null
}

export type AttendanceStatus = 'present' | 'late' | 'early_leave' | 'absent' | 'incomplete' | 'leave' | 'time_permit'

export interface AttendanceDayRow {
  id: string
  employee_id: string
  employee_number: string
  full_name: string
  department_id: string | null
  department_name: string | null
  branch_id: string | null
  branch_name: string | null
  job_title: string | null
  work_date: string
  shift_name: string | null
  expected_in: string | null
  expected_out: string | null
  check_in: string | null
  check_out: string | null
  late_minutes: number
  early_minutes: number
  worked_minutes: number
  is_rest_day: boolean
  status: AttendanceStatus
  source: 'auto' | 'manual'
  edited_by: string | null
  edited_at: string | null
  edit_reason: string | null
  /** 00144: نقص الدقائق والاستقطاع المقترح */
  required_minutes: number
  permit_minutes: number
  shortfall_minutes: number
  overtime_minutes: number
  proposed_deduction_minutes: number
  proposed_deduction_days: number
  deduction_reason: string | null
  deduction_waived: boolean
  waive_reason: string | null
}

export interface AttendanceFilters {
  from: string
  to: string
  branchId?: string | null
  departmentId?: string | null
  status?: AttendanceStatus | null
  search?: string
  limit?: number
}

export interface HrLeave {
  id: string
  employee_id: string
  kind: 'leave' | 'time_permit'
  leave_type: string
  start_date: string
  end_date: string
  start_time: string | null
  end_time: string | null
  status: 'pending' | 'approved' | 'rejected' | 'cancelled'
  approved_at: string | null
  notes: string | null
  employees?: { full_name: string; employee_number: string; department_id: string | null } | null
}

export interface AttendanceDeduction {
  id: string
  employee_id: string
  period_month: string
  amount: number
  days: number
  reason: string
  created_at: string
  /** 00170/00185 — استقطاع ناتج عن كشف معتمد (لا يُحذف من الحضوريات) */
  source_disclosure_id?: string | null
  employees?: { full_name: string; employee_number: string } | null
  disclosure?: { ref_no: string | null } | null
}

/** 00185 — حالة آخر تصدير للشهر والتغييرات بعده */
export interface MonthExportStatus {
  export_id: string | null
  version?: number
  status: 'exported' | 'approved' | null
  exported_at?: string
  /** 00256-ج — مرحلة معاون المدير المفوض: pending = لم يراجع بعد (المالية لا ترى الكشف)؛ approved = وصل إلى المالية */
  review_status?: 'pending' | 'approved' | null
  reviewed_at?: string | null
  reviewed_by_name?: string | null
  changes_after: number
  deductions_after: number
  disclosure_deductions_after: number
  /** 00304: صفوف قسط السلفة فيها لا يطابق واقع السلف الآن (سداد نقدي/سلفة جديدة بعد التصدير) — يمنع الاعتماد حتى إعادة التصدير */
  advance_changes?: number
  needs_reexport: boolean
  /** 00186 — أيام مجدولة ماضية بلا احتساب (الشهر الحالي/غير المعتمد) */
  unevaluated_days?: number
  unevaluated_employees?: number
}

/** 00193 — خلية يوم في شبكة الشهر (غرفة العمليات) */
export type AttendanceGridStatus = AttendanceStatus | 'pending' | 'future' | 'none' | 'rest'
export interface AttendanceGridCell {
  d: string
  s: AttendanceGridStatus
  rest: boolean
  src: 'auto' | 'manual' | null
  in: string | null
  out: string | null
  w: number
  late: number
  early: number
  short: number
  ot: number
  permit: number
  has_permit?: boolean
  pm: number
  pd: number
  waived: boolean
  note: string | null
}
export interface AttendanceGridRow {
  employee_id: string
  employee_number: string
  full_name: string
  job_title: string | null
  department_id: string | null
  department_name: string | null
  branch_name: string | null
  contract_type: string | null
  days: AttendanceGridCell[]
  present_days: number
  late_days: number
  early_days: number
  incomplete_days: number
  absent_days: number
  leave_days: number
  rest_days: number
  unevaluated_days: number
  worked_minutes: number
  late_minutes: number
  early_minutes: number
  shortfall_minutes: number
  overtime_minutes: number
  permit_minutes: number
  proposed_minutes: number
  proposed_days: number
}
/** 00193 — حالة اعتماد حضورية الشهر (المرحلة 1 → 2) */
/** 00216 — ميزان بنك الساعات لموظف في شهر (ops_hour_bank_month) */
export interface HourBankRow {
  employee_id: string; employee_number: string | null; full_name: string | null; department_name: string | null
  enabled: boolean; shift_minutes: number; covered_days: number
  days_counted: number; days_absent: number; days_leave_paid: number; days_leave_unpaid: number; days_short: number; required_days: number
  required_minutes: number; credited_minutes: number; net_minutes: number; deduction_minutes: number; surplus_minutes: number
  credit_days: number; credit_cap_days: number; credit_capped: boolean; grace_minutes: number
}

export interface AttendanceConfirmation {
  month: string
  status: 'open' | 'confirmed' | 'reopened'
  confirmed: boolean
  confirmed_at: string | null
  confirmed_by_name: string | null
  confirm_count: number
  reopened_at: string | null
  reopened_by_name: string | null
  reopen_reason: string | null
  pending_auto: number
  pending_days: Array<{ employee_id: string; full_name: string; work_date: string; would_be: string | null }>
  deductions_after: number
  unevaluated_days: number
  employees: number
  locked: boolean
  required: boolean
  export: MonthExportStatus
  snapshot: Record<string, number>
  can_export: boolean
}

/** 00185 — تفاصيل استقطاعات موظف في شهر (مع مرجع الكشف) */
export interface EmployeeMonthDeduction {
  id: string
  amount: number
  days: number
  reason: string
  created_at: string
  created_by_name: string | null
  source_disclosure_id: string | null
  disclosure_ref: string | null
  disclosure_type: string | null
  disclosure_date: string | null
}

export interface AttendanceAudit {
  id: string
  employee_id: string
  work_date: string
  action: 'edit' | 'deduction_add' | 'deduction_delete' | 'export' | 'approve' | 'reset_auto' | 'waive' | 'unwaive' | 'confirm' | 'reopen' | 'auto_blocked' | 'leave_sync'
  before: Record<string, unknown> | null
  after: Record<string, unknown> | null
  reason: string
  actor: string | null
  created_at: string
}

/** يوم من أيام الموظف في الشهر (hr_employee_month_days) — لتفاصيل كشف المالية */
export interface EmployeeMonthDay {
  work_date: string
  shift_name: string | null
  expected_in: string | null
  expected_out: string | null
  check_in: string | null
  check_out: string | null
  late_minutes: number
  early_minutes: number
  worked_minutes: number
  is_rest_day: boolean
  status: AttendanceStatus
  source: 'auto' | 'manual'
  edit_reason: string | null
  permit_minutes: number
  shortfall_minutes: number
  overtime_minutes: number
  proposed_deduction_minutes: number
  proposed_deduction_days: number
  deduction_waived: boolean
  waive_reason: string | null
  /** 00202: سبب الاستقطاع المقترح أو وسم «يوم غير مدفوع» */
  deduction_reason?: string | null
}

/** صف سجل التدقيق بأسماء (hr_attendance_audit_list) */
export interface AttendanceAuditRow extends AttendanceAudit {
  employee_number: string
  full_name: string
  department_name: string | null
  actor_name: string | null
}

export interface MonthExport {
  id: string
  period_month: string
  version: number
  status: 'exported' | 'superseded' | 'approved'
  rows_count: number
  exported_at: string
  approved_at: string | null
  review_status?: 'pending' | 'approved'
  reviewed_at?: string | null
}

export interface OpsExportRow {
  id: string
  employee_id: string
  employee_number: string | null
  full_name: string | null
  department_name: string | null
  branch_name: string | null
  job_title: string | null
  contract_type: string | null
  working_days: number
  days_present: number
  days_late: number
  days_absent: number
  days_incomplete: number
  days_leave: number
  late_minutes: number
  early_minutes: number
  ops_deduction_amount: number
  ops_deduction_days: number
  ops_deduction_reasons: string | null
  auto_deduction_minutes: number
  auto_deduction_days: number
  overtime_minutes: number
  shortfall_minutes: number
  /** 00184 — تفصيل الإجازات وأيام الاستقطاع التلقائي حسب مصدرها */
  days_leave_paid?: number
  days_leave_unpaid?: number
  auto_absence_days?: number
  auto_shortfall_days?: number
}

export interface PayrollSheetRow extends OpsExportRow {
  auto_deduction_amount: number
  /** 00247 — مراجعة معاون المدير المفوض: حالة المراجعة، نسبة التخفيض العامة، تخفيف هذا الصف (مطروح من الاستقطاعات في الصافي النهائي) */
  review_status?: 'pending' | 'approved' | null
  reviewed_at?: string | null
  review_pct?: number | null
  review_relief_amount?: number | null
  review_note?: string | null
  review_relief?: Record<string, { mode: 'waive' | 'amount'; amount: number; reason: string }> | null
  /** 00216/00217 — بنك الساعات الشهري: المطلوب/المعمول/الصافي بالدقائق ورصيد الإجازة الممنوح من الفائض */
  hour_bank_enabled?: boolean | null
  hour_bank_required_minutes?: number | null
  hour_bank_credited_minutes?: number | null
  hour_bank_net_minutes?: number | null
  hour_bank_credit_days?: number | null
  /** 00184 — مبلغ أيام استقطاع العمليات، الأيام المدفوعة (يومي)، الإجمالي قبل الاستقطاع، إجمالي الاستقطاعات */
  ops_deduction_days_amount?: number | null
  payable_days?: number | null
  gross_amount?: number | null
  deductions_total?: number | null
  /** 00186 — الأيام المجدولة في الشهر، وغير المحتسبة منها (يجب أن تكون 0 بعد التصدير)، ودقائق الشفت لمعادلة الدقيقة */
  scheduled_days?: number
  unevaluated_days?: number
  shift_minutes?: number
  /** 00187 — الفترة المشمولة بالتصدير وأجر اليوم ونسبة التناسب (1 = شهر مكتمل) وهل قُيّد الاستقطاع التلقائي بالسقف */
  period_from?: string | null
  period_to?: string | null
  covered_days?: number | null
  days_in_month?: number | null
  day_rate?: number | null
  proration_ratio?: number | null
  auto_deduction_capped?: boolean
  /** 00188 — أساس مبلغ الاستقطاع التلقائي (salary | fixed | disabled) وهل قُيّدت أيامه بالسقف الشهري */
  auto_deduction_basis?: 'salary' | 'fixed' | 'disabled' | null
  /** 00195: اسم قاعدة الاستقطاع التلقائي التي طُبّقت على الموظف («مستثنى» إن كان مستثنى) */
  auto_deduction_rule?: string | null
  /** 00201: نموذج الراتب الشهري المُطبَّق في هذا الصف */
  salary_model?: 'earned_days' | 'full_minus_absence' | 'daily' | null
  days_rest?: number | null
  auto_deduction_days_capped?: boolean
  /** 00191 — قسط السلفة المستقطع تلقائياً هذا الشهر (ضمن إجمالي الاستقطاعات) */
  advance_installment?: number | null
  /** 00251 — ضريبة الآلية المؤجرة: نسبة × الإجمالي المستحق، سطر مستقل ضمن إجمالي الاستقطاعات */
  rented_tax_pct?: number | null
  rented_tax_amount?: number | null
  rented_tax_vehicle?: string | null
  rented_tax_source?: 'auto' | 'custom' | 'exempt' | null
  /** 00353 — ساعات العمل الإضافي المصروفة بقرار المعاون: تُضاف إلى الصافي فقط (لا إجمالي ولا ضريبة) */
  overtime_amount?: number | null
  overtime_paid_minutes?: number | null
  /** 00392: أيام الشهر المتبقية بعد يوم التصدير المفترض دفعها للشهري (لم تُقيَّم بعد) */
  days_presumed?: number | null
  /** 00300: ما زاد من الاستقطاعات على الإجمالي — يُرحَّل تلقائياً إلى أول شهر مفتوح عند اعتماد المالية */
  uncollected_amount?: number | null
  export_id: string
  export_version: number
  export_status: 'exported' | 'approved'
  exported_at: string
  row_id: string
  pay_type: ContractType | null
  base_salary: number | null
  daily_rate: number | null
  allowances_total: number | null
  fixed_deductions_total: number | null
  proposed_net: number | null
  final_net: number | null
  finance_note: string | null
}

/** 00194 — صف التحقق الحسابي لكشف الرواتب (المالية) */
export type PayrollReconcileIssue = 'SALARY_MISSING' | 'GROSS_MISMATCH' | 'DEDUCTIONS_MISMATCH' | 'RENTED_TAX_MISMATCH' | 'NET_MISMATCH' | 'FINAL_NEGATIVE' | 'NET_NOT_FLOORED' | 'DAYS_UNCLASSIFIED' | 'UNEVALUATED_DAYS' | 'ATTENDANCE_CHANGED' | 'AUTO_DEDUCTION_CHANGED' | 'OPS_DEDUCTIONS_CHANGED' | 'PAYABLE_DAYS_CHANGED' | 'OVERTIME_CHANGED'
export interface PayrollReconcileRow {
  row_id: string
  employee_id: string
  employee_number: string | null
  full_name: string | null
  department_name: string | null
  branch_name: string | null
  pay_type: ContractType | null
  gross_stored: number | null
  gross_expected: number | null
  deductions_stored: number | null
  deductions_expected: number | null
  net_stored: number | null
  net_expected: number | null
  final_net: number | null
  components: Record<string, number | string | null>
  live: Record<string, number | null>
  issues: PayrollReconcileIssue[]
  money_ok: boolean
  attendance_ok: boolean
  ok: boolean
}

export interface SalaryProfile {
  employee_id: string
  status: 'pending' | 'defined'
  pay_type: ContractType
  base_salary: number
  daily_rate: number
  allowances: Record<string, number>
  fixed_deductions: Record<string, number>
  currency: string
  notes: string | null
  set_at: string | null
}

export interface FinanceNotice {
  id: string
  employee_id: string
  kind: 'salary_pending' | 'termination_settlement'
  payload: Record<string, unknown>
  is_done: boolean
  created_at: string
  employees?: { full_name: string; employee_number: string; contract_type: ContractType } | null
}

export interface HrDashboardStats {
  employees_active: number
  employees_terminated: number
  hired_this_month: number
  terminated_this_month: number
  by_department: Array<{ name: string; count: number }>
  by_branch: Array<{ name: string; count: number }>
  today: { present: number; late: number; absent: number; incomplete: number; leave: number }
  leaves_today: number
  salary_pending: number
  unmatched_punches: number
  shifts: Array<{ name: string; count: number }>
  /** 00224 — رسومات الرئيسية (اختيارية لتوافق الاستجابات القديمة) */
  attendance_30d?: Array<{ d: string; present: number; late: number; absent: number; incomplete: number; leave: number }>
  movement_6m?: Array<{ month: string; hired: number; terminated: number }>
  by_contract?: { monthly: number; daily: number }
  by_status?: { active: number; on_leave: number; suspended: number }
  by_gender?: { male: number; female: number; unknown: number }
  tenure?: { lt1: number; y1_3: number; gt3: number }
  leaves_month?: Array<{ name: string; count: number }>
  leaves_pending?: number
  month_attendance?: { present: number; absent: number; late: number; days: number }
  incomplete_profiles?: number
}

export const ATTENDANCE_STATUS_LABELS: Record<AttendanceStatus, string> = {
  present: 'حاضر', late: 'متأخر', early_leave: 'خروج مبكر', absent: 'غائب', incomplete: 'بصمة ناقصة', leave: 'إجازة', time_permit: 'زمنية',
}
export const ATTENDANCE_STATUS_ORDER: AttendanceStatus[] = ['late', 'absent', 'incomplete', 'early_leave', 'present', 'leave', 'time_permit']
export const TERMINATION_LABELS: Record<TerminationType, string> = {
  resignation: 'استقالة', dismissal: 'فصل', contract_end: 'انتهاء عقد', retirement: 'تقاعد', death: 'وفاة',
}
export const DOC_TYPE_LABELS: Record<DocType, string> = {
  photo: 'الصورة الشخصية', national_id_front: 'البطاقة الموحدة — وجه', national_id_back: 'البطاقة الموحدة — ظهر',
  residence_front: 'بطاقة السكن — وجه', residence_back: 'بطاقة السكن — ظهر',
  driving_license: 'إجازة السوق', contract: 'العقد', health_cert: 'الشهادة الصحية', passport: 'جواز السفر', other: 'مستمسك آخر',
}
export const EMPLOYMENT_STATUS_LABELS: Record<EmploymentStatus, string> = { active: 'نشط', on_leave: 'في إجازة طويلة', suspended: 'موقوف', terminated: 'منتهية خدمته' }
/** 00390 */
export interface ManagerCandidate { id: string; employee_number: string; full_name: string; job_title: string | null; department_name: string | null }
export const CONTRACT_LABELS: Record<ContractType, string> = { monthly: 'راتب شهري', daily: 'أجر يومي' }
export const WEEKDAYS_AR = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
export const GOVERNORATES_IQ = ['بغداد', 'البصرة', 'نينوى', 'أربيل', 'النجف', 'كربلاء', 'كركوك', 'الأنبار', 'ديالى', 'ذي قار', 'بابل', 'واسط', 'ميسان', 'المثنى', 'القادسية', 'صلاح الدين', 'السليمانية', 'دهوك']

// ─── 00143: الاستيراد والهيكل التنظيمي ───
export interface ImportEmployeeRow {
  employee_number: string
  full_name: string
  department?: string
  branch?: string
  shift?: string
  contract_type?: ContractType
  hire_date?: string
  job_title?: string
  phone?: string
  phone2?: string
  email?: string
  mother_name?: string
  gender?: 'male' | 'female'
  birth_date?: string
  birth_place?: string
  marital_status?: string
  education?: string
  national_id_number?: string
  residence_card_number?: string
  governorate?: string
  address?: string
  emergency_contact_name?: string
  emergency_contact_phone?: string
  blood_type?: string
  biometric_pin?: string
}
export interface ImportRowResult {
  row: number
  employee_number: string | null
  full_name: string | null
  ok: boolean
  id: string | null
  errors: string[]
  /** 00153: تحذيرات لا تمنع الاستيراد (مثل مسمى غير معرَّف) */
  warnings?: string[]
}
export interface ImportResult { dry_run: boolean; total: number; ok: number; failed: number; warned?: number; rows: ImportRowResult[] }

export interface HrDepartment {
  id: string
  name: string
  code: string
  parent_id: string | null
  is_active: boolean
  manager_id: string | null
  manager_name: string | null
  employees_active: number
  employees_total: number
  children: number
  created_at: string
  /** 00153: عقدة مسمى وظيفي (لا قسم) */
  is_job_title: boolean
  /** 00153: هذا المسمى يقود آليات الشركة */
  drives_vehicles: boolean
  /** 00156: تخصص صيانة (المسمى فني) أو null */
  maintenance_specialty?: string | null
}

/** 00153: مسمى وظيفي للاختيار (hr_job_titles) */
export interface HrJobTitle {
  id: string
  name: string
  code: string
  department_id: string
  department_name: string
  drives_vehicles: boolean
  is_active: boolean
  employees_active: number
  maintenance_specialty?: string | null
}

// ─────────── 00144: السياسة والإجازات والأرصدة ───────────
export interface DeductionTier { from: number; to: number | null; minutes?: number | null; day_fraction?: number | null }
export interface HrPolicy {
  /** 00191 — سياسة السلف: أقصى نسبة للقسط الشهري من الراتب (0.1–1) وهل تُمنع سلفة جديدة ما دامت سلفة مفتوحة */
  advance_max_installment_ratio?: number
  advance_block_if_open?: boolean
  annual_leave_days_default: number
  balance_mode: 'annual_upfront' | 'monthly_accrual'
  carry_over: boolean
  carry_over_max_days: number
  permits_per_leave_day: number
  permit_max_minutes: number
  permits_max_per_month: number | null
  /** 00389-أ: تنبيه HR قبل انتهاء وثيقة الموظف (أيام 1–365) */
  doc_expiry_alert_days?: number
  /** 00197: الطلب بأثر رجعي */
  backdated_requests_enabled?: boolean
  backdated_max_days?: number
  backdated_alert_per_month?: number
  grace_minutes_default: number
  deduction_basis: 'shortfall'
  deduction_tiers: DeductionTier[]
  absent_day_deduction_days: number
  incomplete_punch_as_absent: boolean
  /** إعداد كشف البصمات الناقصة المستقل؛ لا يعني تفعيل الخصم. */
  missing_punch_threshold?: number
  missing_punch_fixed_amount?: number
  overtime_enabled: boolean
  overtime_min_block_minutes: number
  overtime_minutes_per_leave_day: number | null
  /** 00353: الساعات الإضافية المدفوعة (افتراضياً متوقفة) */
  paid_overtime_enabled?: boolean
  paid_overtime_unit?: 'minutes' | 'hours'
  paid_overtime_before_shift?: boolean
  paid_overtime_after_shift?: boolean
  paid_overtime_min_block_minutes?: number
  alert_late_days_per_month: number
  alert_shortfall_minutes_per_month: number
  alert_absent_days_per_month: number
  alert_balance_low_days: number
  /** 00179: محرك البصمة */
  punch_window_hours?: number
  /** 00255: أقل فاصل بين الدخول والخروج ليُعتبر خروجاً (0 = إيقاف) · تقييد النافذة تلقائياً كي لا تتداخل الأيام */
  min_punch_gap_minutes?: number
  punch_window_auto_cap?: boolean
  auto_evaluate_enabled?: boolean
  evaluate_lookback_days?: number
  /** 00187: احتساب الراتب الشهري */
  salary_day_basis?: 'fixed_30' | 'calendar_days'
  /** 00201: earned_days = أجر اليوم × الأيام المستحقة (افتراضي) · full_minus_absence = الراتب كاملاً ناقص الغياب (قديم) */
  salary_model?: 'earned_days' | 'full_minus_absence'
  pay_rest_days?: boolean
  prorate_partial_month?: boolean
  prorate_allowances?: boolean
  auto_deduction_cap_ratio?: number
  /** 00188: تحكم الاستقطاع التلقائي */
  auto_deduction_enabled?: boolean
  deduct_absence_enabled?: boolean
  deduct_shortfall_enabled?: boolean
  deduct_unpaid_leave_enabled?: boolean
  auto_deduction_amount_mode?: 'salary' | 'fixed'
  fixed_absent_day_amount?: number
  fixed_shortfall_minute_amount?: number
  max_auto_deduction_days_per_month?: number
  /** 00196: طريقة احتساب نقص الدقائق */
  shortfall_method?: ShortfallMethod
  shortfall_multiplier?: number
  shortfall_block_minutes?: number
  /** 00216/00218: بنك الساعات — سقف تحويل الفائض اليومي (بقاء بعد النهاية + مجيء مبكر) إلى رصيد إجازة (يوم/شهر) */
  hour_bank_credit_cap_days?: number
  /** 00193 — لا تصدير للمالية قبل اعتماد حضورية الشهر في غرفة العمليات */
  require_attendance_confirmation?: boolean
}
export interface LeaveType {
  id: string
  code: string
  name: string
  kind: 'leave' | 'time_permit'
  is_paid: boolean
  consumes_balance: boolean
  deduction_days_per_day: number
  requires_attachment: boolean
  max_days_per_request: number | null
  max_minutes: number | null
  sort_order: number
  is_active: boolean
}
export interface LeaveBalance {
  year: number
  granted: number
  accrued: number
  carried: number
  adjusted: number
  used_leave_days: number
  used_permit_days: number
  permits_count: number
  overtime_days: number
  reversed: number
  remaining: number
  /** 00305 */
  pending_reserved?: number
  available?: number
  permits_per_leave_day: number
}
export interface LeaveLedgerEntry {
  id: string
  employee_id: string
  year: number
  kind: 'grant' | 'adjust' | 'consume' | 'permit' | 'overtime' | 'carry_over' | 'reversal'
  days: number
  leave_id: string | null
  period_month: string | null
  note: string | null
  created_at: string
}
export type LeaveScope = 'mine' | 'team' | 'all' | 'garage'   // 00208: garage = موظفو قسم الكراج
export interface LeaveRequestRow {
  id: string
  employee_id: string
  employee_number: string
  full_name: string
  department_name: string | null
  kind: 'leave' | 'time_permit'
  type_code: string | null
  type_name: string | null
  is_paid: boolean | null
  consumes_balance: boolean | null
  start_date: string
  end_date: string
  start_time: string | null
  end_time: string | null
  days: number
  minutes: number
  status: 'pending' | 'approved' | 'rejected' | 'cancelled'
  notes: string | null
  attachment_path: string | null
  manager_id: string | null
  manager_name: string | null
  requested_by: string | null
  decided_at: string | null
  decision_note: string | null
  cancelled_reason: string | null
  created_at: string
  can_decide: boolean
  can_cancel?: boolean   // 00208: من أدخل الطلب (الكراج) أو HR أو المعتمد
  /** 00197: طلب بأثر رجعي (ليوم سابق) */
  is_backdated?: boolean
  backdated_reason?: string | null
  backdated_days?: number
  /** 00239: جهة التقديم (self/manager/hr/garage/ops_room/admin) واسم المُقدِّم عندما لا يكون الموظف نفسه */
  requested_via?: LeaveRequestedVia | null
  requester_name?: string | null
  /** 00396: بلا سلسلة وبلا مدير قادر على البتّ ⇒ أُحيل الطلب إلى الموارد البشرية (مع السبب) */
  hr_fallback?: boolean | null
  hr_fallback_reason?: string | null
}
export type LeaveRequestedVia = 'self' | 'manager' | 'hr' | 'garage' | 'ops_room' | 'admin'
/** 00239: ملخص وحدة طلبات الإجازة في غرفة العمليات */
export interface OpsLeavesSummary { pending: number; via_ops_pending: number; via_ops_month: number; on_leave_today: number }
/** 00239: نتيجة بحث الموظف لغرفة العمليات — كل الملاك (حتى بلا حساب/بصمة) */
export interface OpsLeaveEmployee { id: string; full_name: string; employee_number: string; job_title: string | null; department_name: string | null; has_account: boolean; has_biometric: boolean; manager_name: string | null; manager_id?: string | null; department_id?: string | null }
export interface LeaveRequestInput {
  employeeId: string
  typeId: string
  start: string
  end: string
  startTime?: string | null
  endTime?: string | null
  notes?: string | null
  attachment?: string | null
  /** 00197: سبب الطلب ليوم سابق (إلزامي عندما يكون تاريخ البداية قبل اليوم) */
  backdatedReason?: string | null
}
export interface HrAlert {
  id: string
  employee_id: string
  employee_number: string
  full_name: string
  department_name: string | null
  manager_name: string | null
  period_month: string
  kind: 'late_repeat' | 'shortfall' | 'absent_repeat' | 'balance_low'
  value: number
  threshold: number
  details: string | null
  acknowledged_at: string | null
  created_at: string
}
export interface LeavesDashboard { pending: number; approved_today: number; open_alerts: number; permits_this_month: number }
export interface MyEmployee {
  id: string
  full_name: string
  employee_number: string
  job_title: string | null
  department_id: string | null
  department_name: string | null
  manager_id: string | null
  manager_name: string | null
  has_biometric: boolean
  reports_count: number
}

/** 00195 — وحدة الاستقطاعات التلقائية (التطوير المركزية) */
export type ShortfallMethod = 'tiers' | 'actual' | 'multiplier' | 'blocks' | 'hour_bank'
export type DeductionRuleSettings = Pick<HrPolicy, 'shortfall_method' | 'shortfall_multiplier' | 'shortfall_block_minutes' | 'hour_bank_credit_cap_days' | 'grace_minutes_default' | 'deduction_tiers' | 'absent_day_deduction_days' | 'incomplete_punch_as_absent' | 'auto_deduction_enabled' | 'deduct_absence_enabled' | 'deduct_shortfall_enabled' | 'deduct_unpaid_leave_enabled' | 'auto_deduction_amount_mode' | 'fixed_absent_day_amount' | 'fixed_shortfall_minute_amount' | 'max_auto_deduction_days_per_month' | 'auto_deduction_cap_ratio'>
export type DeductionTargetType = 'branch' | 'department' | 'employee'
export interface DeductionRuleTarget { id: string; target_type: DeductionTargetType; target_id: string; name: string | null }
/** 00249: تقارير سلوك الموظفين */
export type BehaviorPeriodKind = 'monthly' | 'quarterly' | 'half_yearly' | 'yearly'
export type BehaviorGrade = 'excellent' | 'very_good' | 'good' | 'fair' | 'poor'
export interface BehaviorPeriod { kind: BehaviorPeriodKind; period_from: string; period_to: string; period_to_effective: string; prev_from: string; prev_to: string; label: string }
export interface BehaviorIndices { attendance: number; punctuality: number; early: number; complete: number; consistency: number }
export interface BehaviorMetrics {
  employee_id: string; scheduled_days: number; leave_days: number; expected_days: number; worked_days: number; present_days: number
  late_days: number; late_minutes: number; early_days: number; early_minutes: number; absent_days: number; incomplete_days: number
  extra_minutes: number; avg_in_offset: number | null; sd_in_offset: number | null; perfect_days: number; max_perfect_streak: number; score: number
}
export interface BehaviorEmployeeRow extends BehaviorMetrics {
  employee_number: string; full_name: string; department_id: string | null; department_name: string | null; branch_name: string | null; job_title: string | null
  indices: BehaviorIndices; grade: BehaviorGrade; prev_score: number | null; prev_grade: BehaviorGrade | null; delta: number | null; rank: number; chronic_late: boolean; high_absence: boolean
}
export interface BehaviorSummary {
  employees: number; avg_score: number | null; prev_avg_score: number | null; attendance_rate: number | null; punctuality_rate: number | null; early_leave_rate: number | null
  absence_rate: number | null; incomplete_rate: number | null; late_minutes: number; early_minutes: number; extra_minutes: number; absent_days: number
  avg_late_minutes_per_late_day: number | null; chronic_late: number; perfect: number; grades: Record<BehaviorGrade, number>; improved: number; declined: number
}
export interface BehaviorTrendPoint { label: string; from: string; to: string; avg_score: number | null; late_rate: number | null; absence_rate: number | null; early_rate: number | null; employees: number }
export interface BehaviorWeekday { dow: number; late_days: number; absent_days: number; early_days: number; worked_days: number; late_rate?: number | null; avg_in_offset?: number | null }
export interface BehaviorDepartment { department_id: string | null; name: string; employees: number; avg_score: number | null; late_rate: number | null; absence_rate: number | null }
export interface BehaviorReport {
  period: BehaviorPeriod; summary: BehaviorSummary | null; trend: BehaviorTrendPoint[]; weekdays: BehaviorWeekday[]; departments: BehaviorDepartment[]; employees: BehaviorEmployeeRow[]
  weights: Record<keyof BehaviorIndices, number>
}
export interface BehaviorDay { date: string; dow: number; status: AttendanceStatus; late: number; early: number; in: string | null; out: string | null; expected_in: string | null; expected_out: string | null; worked: number; in_offset: number | null; extra: number; source: 'auto' | 'manual'; grace?: number; is_late?: boolean; is_early?: boolean }
export interface BehaviorEmployeeTrend { label: string; from: string; to: string; score: number; late_days: number; absent_days: number; early_days: number; late_minutes: number }
export interface BehaviorEmployeeReport {
  period: BehaviorPeriod
  employee: { id: string; employee_number: string; full_name: string; department_name: string | null; branch_name: string | null; job_title: string | null; hire_date: string; biometric_pin: string | null }
  current: (BehaviorMetrics & { idx_attendance: number; idx_punctuality: number; idx_early: number; idx_complete: number; idx_consistency: number; grade: BehaviorGrade }) | null
  previous: (BehaviorMetrics & { idx_attendance: number; idx_punctuality: number; idx_early: number; idx_complete: number; idx_consistency: number; grade: BehaviorGrade }) | null
  rank: number | null; population: number; trend: BehaviorEmployeeTrend[]; weekdays: BehaviorWeekday[]; in_histogram: Array<{ bucket: number; days: number }>; days: BehaviorDay[]
  weights: Record<keyof BehaviorIndices, number>
}
/** 00250: سلسلة فترات للمقارنة */
export interface BehaviorSeriesPeriod { label: string; from: string; to: string; employees: number; avg_score: number | null; attendance_rate: number | null; punctuality_rate: number | null; absence_rate: number | null; early_rate: number | null; late_minutes: number; chronic_late: number; grades: Record<BehaviorGrade, number> }
export interface BehaviorSeriesEmployee { employee_id: string; employee_number: string; full_name: string; department_name: string | null; scores: Array<number | null>; last_score: number | null; first_score: number | null; slope: number | null; periods_with_data: number; trend: 'improving' | 'declining' | 'stable' | 'insufficient' }
export interface BehaviorSeries { kind: BehaviorPeriodKind; periods: BehaviorSeriesPeriod[]; employees: BehaviorSeriesEmployee[] }
/** 00248: شريحة احتساب (مجيء مبكر/بقاء بعد النهاية) — حتى `upto` دقيقة بنسبة `pct`% تدريجياً؛ ما بعد آخر شريحة = 0 */
export interface CreditTier { upto: number; pct: number }
export interface CreditTiers { early_in: CreditTier[]; late_out: CreditTier[] }
export interface DeductionRule {
  id: string
  name: string
  description: string | null
  is_default: boolean
  is_active: boolean
  settings: DeductionRuleSettings
  updated_at: string
  targets: DeductionRuleTarget[]
  employees_count: number
}
export interface DeductionExemption {
  id: string; target_type: DeductionTargetType; target_id: string; name: string | null; reason: string; from_date: string; to_date: string | null; created_at: string; active: boolean
}
export type DeductionRuleSource = 'exempt' | 'employee' | 'department' | 'branch' | 'default'
export interface DeductionEmployeeRow {
  employee_id: string; employee_number: string; full_name: string; job_title: string | null; department_id: string | null; department_name: string | null; branch_id: string | null; branch_name: string | null; contract_type: string | null
  rule_id: string | null; rule_name: string | null; source: DeductionRuleSource; exempt: boolean; exempt_reason: string | null; exempt_until: string | null; enabled: boolean; amount_mode: 'salary' | 'fixed'
  month_minutes: number; month_days: number; month_absent: number; month_shortfall: number; month_waived: number
}
export interface DeductionSimulation { enabled: boolean; minutes: number; days: number; shortfall_days: number; absent_days: number; incomplete_days: number; amount_mode: 'salary' | 'fixed'; day_rate: number; minute_rate: number; amount: number; method?: ShortfallMethod }
/** 00196: محاكاة تفصيلية — حالة يوم + حالة شهر ⇒ خطوات شرح + سلّم النقص */
export interface DeductionSimCase {
  shift_minutes: number; base_salary: number; pay_type: 'monthly' | 'daily'
  late_minutes: number; early_minutes: number; paid_permit_minutes: number; unpaid_permit_minutes: number
  absent_days: number; incomplete_days: number; unpaid_leave_days: number; paid_leave_days: number; leave_deduction_days_per_day: number
  /** 00202: الشهر (YYYY-MM-01) لاحتساب أيام الشهر الفعلية — افتراضياً الشهر الحالي */ month?: string
}
export interface DeductionSimStep { key: 'rates' | 'shortfall' | 'method' | 'days' | 'amount'; title: string; text: string }
export interface DeductionSimLadderRow { shortfall: number; minutes: number; days: number; amount: number; within_grace: boolean }
export interface DeductionSimulationV2 {
  enabled: boolean; method: ShortfallMethod; amount_mode: 'salary' | 'fixed'; status: AttendanceStatus
  missing_minutes: number; covered_minutes: number; shortfall_minutes: number; grace_minutes: number
  minutes: number; shortfall_days: number; absent_days: number; incomplete_days: number; unpaid_leave_days: number; paid_leave_days: number; days: number
  day_rate: number; minute_rate: number
  /** 00202 */ salary_model?: 'earned_days' | 'full_minus_absence' | 'daily'; days_in_month?: number; unpaid_days_amount?: number
  amount_shortfall: number; amount_absence: number; amount_incomplete: number; amount_unpaid_leave: number; amount: number; capped: boolean
  steps: DeductionSimStep[]; ladder: DeductionSimLadderRow[]
}
export interface DeductionAuditRow { id: number; action: 'rule_save' | 'rule_delete' | 'target_set' | 'exemption_add' | 'exemption_remove' | 'missing_punch_settings'; rule_id: string | null; rule_name: string | null; before: Record<string, unknown> | null; after: Record<string, unknown> | null; actor: string | null; actor_name: string | null; created_at: string }

/** 00247 — بوابة المالية: هل الشهر مصدَّر وهل اعتمده معاون المدير المفوض (المالية لا ترى الكشف قبل ذلك) */
export interface FinancePayrollGate {
  exported: boolean
  visible: boolean
  export_id?: string
  version?: number
  review_status: 'pending' | 'approved' | null
  reviewed_at?: string | null
  review_pct?: number
  relief_total?: number
}
export type DeputyDeductionKind = 'shortfall' | 'absence' | 'ops' | 'fines'
export interface DeputyKindBreakdown { original: number; relief: number; after: number; mode: 'none' | 'waive' | 'amount'; reason: string | null; set_amount: number | null }
/** 00247 — صف موظف في مراجعة المعاون: الاستقطاعات مفكّكة إلى أنواعها الأربعة + التخفيف + الصافي بعد المراجعة */
export interface DeputyReviewRow {
  export_id: string; export_version: number; review_status: 'pending' | 'approved'; review_pct: number
  row_id: string; employee_id: string; employee_number: string; full_name: string
  department_name: string | null; branch_name: string | null; job_title: string | null; pay_type: 'monthly' | 'daily' | null; shift_minutes: number; day_rate: number | null
  shortfall_minutes: number; shortfall_amount: number; absence_days: number; absence_amount: number; ops_amount: number; ops_reasons: string | null; fines_amount: number; fines_count: number
  reviewable_total: number; relief_total: number; pct_relief: number; deductions_total: number | null; deductions_after: number; gross_amount: number | null; proposed_net: number | null; final_net: number | null
  review_note: string | null
  breakdown: Record<DeputyDeductionKind, DeputyKindBreakdown> & { pct: number; pct_relief: number; reviewable_total: number; relief_total: number; deductions_after: number; final_net_after: number | null; minute_rate: number }
  hour_bank_enabled: boolean | null
  /** 00249 — معفى كلياً من كل استقطاعات الشهر (بسبب) */
  employee_waived?: boolean
}
export interface DeputyPayrollMonth {
  period_month: string; export_id: string; version: number; export_status: 'exported' | 'approved'; exported_at: string
  review_status: 'pending' | 'approved'; reviewed_at: string | null; reviewed_by_name: string | null; review_pct: number
  rows_count: number; employees_with_deductions: number; deductions_total: number; relief_total: number; net_total: number
}
/** 00251 — ضريبة الآليات المؤجرة (وحدة المعاون) */
export interface RentedTaxOverride { mode: 'exempt' | 'custom'; pct: number | null; reason: string; valid_from: string; valid_to: string | null; created_at: string; by: string | null }
export interface RentedTaxEmployee {
  employee_id: string; employee_number: string; full_name: string; department_name: string | null; job_title: string | null
  vehicles: string | null; linked: boolean; pct: number; source: 'auto' | 'custom' | 'exempt' | 'none'; override: RentedTaxOverride | null
  last_month: string | null; last_gross: number | null; last_tax: number | null; last_pct: number | null; has_salary: boolean
}
export interface RentedTaxOverview { pct: number; updated_at: string; updated_by: string | null; last_export_month: string | null; rented_vehicles: number; rented_vehicles_without_driver: number; employees: RentedTaxEmployee[] }
export interface RentedTaxAudit { id: string; employee_id: string | null; employee_number: string | null; full_name: string | null; action: 'pct' | 'exempt' | 'custom' | 'clear'; before: Record<string, unknown> | null; after: Record<string, unknown> | null; reason: string | null; actor_name: string | null; created_at: string }
export interface RentedTaxPreviewRow { employee_id: string; employee_number: string; full_name: string; gross_amount: number | null; stored_pct: number; stored_tax: number; current_pct: number; current_source: string; current_tax: number; export_status: 'exported' | 'approved'; version: number }
export interface DeputyReviewAudit {
  id: string; row_id: string | null; employee_number: string | null; full_name: string | null
  action: 'waive' | 'amount' | 'clear' | 'percent' | 'approve' | 'reopen'; kind: DeputyDeductionKind | null
  before: Record<string, unknown> | null; after: Record<string, unknown> | null; reason: string | null; actor_name: string | null; created_at: string
}

/* ─── 00348 (B): طلبات التعيين لدى الموارد البشرية ─── */
export type HrHireRequestStatusFilter = 'approved' | 'completed' | 'pending' | 'rejected' | 'all'
export interface HrHireRequest {
  id: string; full_name: string; phone: string | null; job_title_id: string; job_title: string; department_id: string | null; department: string | null
  hire_date: string; contract_type: ContractType; shift_id: string | null; shift_name: string | null
  source: 'garage' | 'station' | 'maintenance'; source_label: string; requester_name: string; note: string | null
  status: 'pending' | 'approved' | 'rejected' | 'cancelled' | 'completed'; created_at: string; decided_at: string | null; completed_at: string | null
  employee_id: string | null; employee_number: string | null; days_waiting: number
}

// 00353 — الساعات الإضافية المدفوعة (المعاون)
export interface OvertimeSettings { enabled: boolean; unit: 'minutes' | 'hours'; before_shift: boolean; after_shift: boolean; min_block_minutes: number }
export interface OvertimePayout { id: string; status: 'paid' | 'rejected' | 'cancelled'; amount: number; payable_minutes: number; counted_minutes: number; hour_rate: number; rate_source: 'fixed' | 'salary' | 'none'; unit: 'minutes' | 'hours'; payroll_month: string; note: string | null; decided_at: string; decided_by_name: string | null; settled: boolean; changed_since: boolean }
export interface OvertimeEmployee {
  employee_id: string; employee_number: string; full_name: string; department_name: string | null; job_title: string | null
  days_count: number; early_minutes: number; late_minutes: number; counted_minutes: number; payable_minutes: number
  hour_rate: number; rate_source: 'fixed' | 'salary' | 'none'; shift_minutes: number; day_rate: number | null; amount: number
  fixed_rate: { enabled: boolean; hourly_amount: number; note: string | null } | null
  /** مشمول بالاسم بقرار المعاون (غير المشمول لا يظهر إلا إن كان له قرار سابق) */
  member: boolean
  payout: OvertimePayout | null
}
export interface OvertimeOverview { month: string; settings: OvertimeSettings; payroll_month: string | null; month_locked: boolean; members_count: number; export_status: string | null; export_review_status: string | null; employees: OvertimeEmployee[] }
export interface OvertimeDay { work_date: string; shift_name: string | null; expected_in: string | null; expected_out: string | null; check_in: string | null; check_out: string | null; status: string; early_minutes: number; late_minutes: number; counted_minutes: number; shortfall_minutes: number }
export interface OvertimeRateRow { employee_id: string; employee_number: string; full_name: string; department_name: string | null; job_title: string | null; enabled: boolean; hourly_amount: number; note: string | null; updated_at: string | null; salary_hour_rate: number; salary_source: 'fixed' | 'salary' | 'none'; member: boolean; member_since: string | null; member_note: string | null }
export interface OvertimeMemberEvent { id: string; employee_id: string; employee_number: string; full_name: string; action: 'add' | 'remove'; note: string | null; actor_name: string | null; created_at: string }
export interface OvertimeHistoryRow { id: string; employee_id: string; employee_number: string; full_name: string; period_month: string; payroll_month: string; status: 'paid' | 'rejected' | 'cancelled'; payable_minutes: number; hour_rate: number; rate_source: string; amount: number; note: string | null; decided_at: string; decided_by_name: string | null; cancelled_at: string | null; cancelled_by_name: string | null; cancel_note: string | null }

// 00355 — المنتهية خدماتهم والتصفية النهائية (المالية)
export type SettlementStatus = 'pending' | 'approved' | 'delivered' | 'debt_open' | 'debt_paid' | 'debt_waived'
export interface SettlementAdvanceLine { id: string; ref_no: string; type_name: string; amount: number; repaid: number; remaining: number }
export interface SettlementLines {
  salary_month: string
  salary: { source: 'computed' | 'paid_in_sheet' | 'no_profile'; gross: number; deductions: number; rented_tax: number; overtime: number; net: number; sheet_net?: number; covered_days: number; payable_days: number | null; day_rate: number; period_from: string | null; period_to: string | null; pay_type?: string | null; base_salary?: number | null; daily_rate?: number | null; days_in_month?: number | null; days_present?: number | null; days_absent?: number | null; days_leave_paid?: number | null; note: string | null; export_version?: number }
  leave: { remaining_days: number; day_rate: number; amount: number; year: number }
  advances: SettlementAdvanceLine[]
  advances_total: number
  prior_months_unexported: string[]
  total_due: number
  total_deduct: number
  net: number
  has_profile: boolean
  computed_at: string
}
export interface SettlementRow {
  id: string; ref_no: string; employee_id: string; employee_number: string | null; full_name: string; department_name: string | null; job_title: string | null
  termination_type: TerminationType; termination_label: string; last_day: string; salary_month: string; status: SettlementStatus; status_label: string
  net_amount: number; debt_amount: number; has_profile: boolean; computed_at: string | null; approved_at: string | null; delivered_at: string | null; debt_closed_at: string | null; manager_name: string | null; created_at: string
}
export interface SettlementEvent { id: number; action: string; actor_name: string | null; amount: number | null; note: string | null; created_at: string }
export interface SettlementDetail extends Omit<SettlementRow, 'has_profile'> {
  lines: SettlementLines | Record<string, never>; reason: string | null; approve_note: string | null; delivery_note: string | null; debt_note: string | null; month_locked: boolean; events: SettlementEvent[]
}
export interface SettlementsSummary { pending: number; approved: number; approved_amount: number; debt_open: number; debt_amount: number; delivered_total: number; closed: number }

// 00356 — الكتب الرسمية
export type LetterKind = 'resignation_accept' | 'termination' | 'dismissal' | 'contract_end' | 'retirement' | 'death' | 'settlement' | 'thanks' | 'notice' | 'warning'   // 00357: +thanks/notice/warning
export interface LetterRow { id: string; ref: string; letter_year: number; letter_no: number; kind: LetterKind; kind_label: string; subject: string; employee_id: string | null; employee_number: string | null; full_name: string; department_name: string | null; job_title: string | null; issued_at: string; issued_by_name: string | null; signer_name: string | null; source_kind: string; source_id: string }
export interface OfficialLetter extends LetterRow { hire_date: string | null; body: string[]; payload: Record<string, unknown>; signer_title: string; issued_date?: string }
export interface LetterRef { id: string; ref: string; kind: LetterKind; kind_label: string; issued_at: string }
