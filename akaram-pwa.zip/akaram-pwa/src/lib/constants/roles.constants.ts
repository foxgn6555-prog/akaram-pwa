/** الأدوار النظامية — mirror لقيد CHECK في 00003 + توسعة 00035 (7 بوابات جديدة) */
export const ROLES = {
  EMPLOYEE: 'employee',
  HR_OFFICER: 'hr_officer',
  DEPARTMENT_MANAGER: 'department_manager',
  FINANCE_OFFICER: 'finance_officer',
  IT_ADMIN: 'it_admin',
  SUPER_ADMIN: 'super_admin',
  FIELD_OPS: 'field_ops',
  ADMIN_OPS: 'admin_ops',
  MAINTENANCE: 'maintenance',
  TRANSFER_STATION: 'transfer_station',
  EXECUTIVE_DIRECTOR: 'executive_director',
  DEPUTY_DIRECTOR: 'deputy_director',
  OPS_ROOM: 'ops_room',
  COMPLAINTS_OFFICER: 'complaints_officer',
  MEDIA_OFFICER: 'media_officer',
  CENTRAL_GARAGE_OFFICER: 'central_garage_officer',
  FOLLOW_UP: 'follow_up',
} as const

export type Role = (typeof ROLES)[keyof typeof ROLES]

/** أولوية الدور الأساسي في JWT — mirror لـ app.custom_access_token_hook (محدّث في 00371) */
export const ROLE_PRIORITY: readonly Role[] = [
  ROLES.IT_ADMIN,
  ROLES.SUPER_ADMIN,
  ROLES.EXECUTIVE_DIRECTOR,
  ROLES.DEPUTY_DIRECTOR,
  ROLES.OPS_ROOM,
  ROLES.FINANCE_OFFICER,
  ROLES.HR_OFFICER,
  ROLES.ADMIN_OPS,
  ROLES.FIELD_OPS,
  ROLES.FOLLOW_UP,
  ROLES.MAINTENANCE,
  ROLES.TRANSFER_STATION,
  ROLES.COMPLAINTS_OFFICER,
  ROLES.MEDIA_OFFICER,
  ROLES.CENTRAL_GARAGE_OFFICER,
  ROLES.DEPARTMENT_MANAGER,
  ROLES.EMPLOYEE,
] as const

/** التسميات العربية للأدوار — للشارات والقوائم */
export const ROLE_LABELS: Readonly<Record<Role, string>> = {
  employee: 'متعهد',
  hr_officer: 'موارد بشرية',
  department_manager: 'مسؤول قسم',
  finance_officer: 'مالية',
  it_admin: 'تقنية معلومات',
  super_admin: 'مدير مفوض',
  field_ops: 'عمليات ميدانية',
  admin_ops: 'مسؤول القاطع',
  maintenance: 'صيانة',
  transfer_station: 'محطة تحويلية',
  executive_director: 'مدير تنفيذي',
  deputy_director: 'معاون المدير المفوض',
  ops_room: 'غرفة عمليات',
  complaints_officer: 'مسؤول الشكاوى',
  media_officer: 'مسؤول الإعلام',
  central_garage_officer: 'مسؤول الكراج المركزي',
  follow_up: 'المتابعة',
} as const
