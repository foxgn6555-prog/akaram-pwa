# منظومة البصمة — المصادر القابلة للتوصيل (00139)

## الفصل المعتمد
| الجانب | البوابة | المسار | المحتوى |
|---|---|---|---|
| **التقني** | التطوير المركزية | `/it/integrations/biometric` | تسجيل المصادر بأنماطها، التهيئة (رابط/مفتاح/خريطة حقول)، اختبار الاتصال، «اسحب الآن»، معالجة دفعات ADMS، سجل العمليات |
| **البيانات** | الموارد البشرية | `/hr/biometric` | دفتر البصمات الموحّد، غير المطابَقين، ربط PIN بموظف، اشتقاق الحضور اليومي |

## الأنماط الأربعة (تعمل معاً في آن واحد)
| النمط | `mode` | الاتجاه | متى |
|---|---|---|---|
| جهاز ZKTeco دفع | `adms_push` | الجهاز → المنصة | الجهاز مهيأ بـ Cloud Server URL = `…/functions/v1/adms-receiver` |
| API تطبيق مشترك | `app_api_pull` | المنصة → API المزود | **المرحلة الحالية (مؤقت)** |
| شبكة داخلية | `lan_pull` | المنصة → الجهاز/الخدمة داخلياً | يتطلب وصول الخادم للعنوان الداخلي (VPN/نفق) |
| عام | `generic_pull` | المنصة → أي JSON | خريطة حقول + مسار المصفوفة |

## عقد `app_api_pull` (يلتزم به التطبيق المزود)
```
GET {base_url}{path}?from=<ISO>&to=<ISO>
Headers: X-API-Key: <api_key>      (أو Authorization: Bearer …)
200 → { "records": [ { "pin": "7001", "at": "2026-09-20T08:02:00+03:00",
                       "direction": "in|out|0|1|…", "name": "اختياري", "device_serial": "اختياري" } ] }
```
- تُقبل أيضاً مصفوفة مباشرة أو المفاتيح `data/items/logs/result`؛ وأسماء بديلة للحقول
  (`employee_number/user_id/badge` للـ PIN، `timestamp/punched_at/time` للوقت، `type/status/punch` للاتجاه).
- الأوقات بلا منطقة تُفسَّر بـ `timezone_offset` المهيأ (مثل `+03:00`)، وإلا UTC. epoch ثوانٍ/ملّي مقبول.
- الاتجاه: `0/in/check-in/دخول/حضور` = دخول، `1/out/check-out/خروج/انصراف` = خروج، غير ذلك = غير محدد
  (قابل للتخصيص عبر `in_values/out_values`).

## عقد `lan_pull`
- JSON بنمط ZKTeco: `{ data: [ { user_id|uid|pin, timestamp|checktime, punch|status|checktype, sn } ] }`
- أو نص ATTLOG خام: `PIN<TAB>YYYY-MM-DD HH:MM:SS<TAB>status<TAB>verify` سطر لكل بصمة (المشوّه يُتجاوَز).
- اعتماد Basic (`basic_user/basic_pass`) أو مفتاح في ترويسة.

## مسار البيانات
```
مصدر → (Edge biometric-pull | adms-receiver) → biometric_import_punches / biometric_ingest
     → biometric_punches (unique: جهاز+PIN+وقت+اتجاه ⇒ لا تكرار أبداً)
     → مطابقة: employees.biometric_pin أولاً ثم employee_number
     → HR: biometric_attendance_derive(يوم) → attendance_records (دمج محروس، idempotent)
```

## الأخطاء المرمّزة (تُترجم في الواجهة)
`BIO_FORBIDDEN · BIO_DEVICE_NOT_FOUND · BIO_DEVICE_INACTIVE · BIO_MODE_NOT_PULLABLE · BIO_CONFIG_BASE_URL ·
BIO_CONFIG_MAPPING · BIO_WINDOW_INVALID · BIO_WINDOW_TOO_LARGE · BIO_SOURCE_UNREACHABLE · BIO_SOURCE_UNAUTHORIZED ·
BIO_SOURCE_HTTP · BIO_RESPONSE_SHAPE · BIO_RECORD_PIN · BIO_RECORD_TIME · BIO_IMPORT_INVALID · BIO_PIN_TAKEN ·
BIO_PIN_INVALID · BIO_EMPLOYEE_NOT_FOUND · BIO_DATE_INVALID`

## المنطقة الزمنية (00140) — حرج
- أجهزة ZKTeco ترسل الوقت **المحلي بلا منطقة**؛ لكل جهاز `timezone_offset` (افتراضي `+03:00` بغداد) يحوّله إلى وقت صحيح.
- رد التسجيل يرسل للجهاز `TimeZone=3` المشتق من الحقل نفسه (كان `-3` = إزاحة 6 ساعات).
- فخ SQL مثبت بالاختبار: `at time zone '+03:00'` كنص = إشارة POSIX معكوسة؛ الصحيح `at time zone interval '+03:00'`.
- OPERLOG: أسماء المستخدمين من الجهاز تُحفظ في `biometric_device_users` وتظهر في دفتر HR بجانب PIN غير المطابَق وتُقترح في نموذج الربط.

## وكيل الشبكة الداخلية zk_bridge (00141)
- سحب مباشر حقيقي من الجهاز عبر المنفذ 4370 (node-zklib) من حاسوب داخل الجهة: `tools/zk-bridge/` (README هناك).
- مصادقة بمفتاح لكل جهاز `zkb_…` (RPC `biometric_bridge_rotate_key` لـ IT؛ يُخزَّن SHA-256 فقط، يُعرض مرة واحدة).
- Edge `biometric-bridge` (بلا JWT — `--no-verify-jwt`) → `biometric_bridge_authenticate_public` → `biometric_bridge_import_public` (service_role فقط).
- يرسل الوقت المحلي للجهاز؛ التحويل بمنطقة الجهاز في القاعدة. يرسل مستخدمي الجهاز أيضاً (أسماء).
- كل دفعة/فشل تُسجَّل في `biometric_pulls` بنمط `zk_bridge`؛ آخر اتصال/خطأ على `biometric_devices.bridge_*`.
- اختبارات: SQL `biometric_bridge.sql` (9 كتل) + Vitest `bridge-protocol` 16 (تطابق نسخة الوكيل مع Edge + دورة الوكيل بلا جهاز).

## النشر
1. `supabase db push` (00139 + 00140 + 00141)
2. `supabase functions deploy adms-receiver --no-verify-jwt` و`supabase functions deploy biometric-bridge --no-verify-jwt` (الجهاز/الوكيل لا يحملان JWT)
3. `supabase functions deploy biometric-pull` — يحتاج `SUPABASE_ANON_KEY` ضمن أسرار الدوال (متوفر افتراضياً).
4. في بوابة التطوير المركزية: سجّل مصدر `app_api_pull` برابط المزود ومفتاحه → «اختبار الاتصال» → «اسحب الآن».

## الاختبارات
- SQL: `hr_biometric_sources.sql` (11 كتلة) + `biometric_device_timezone.sql` (9 كتل: منطقة الجهاز/TAB/OPERLOG/منتصف الليل/الدفعات المتراكمة).
- Vitest: `biometric-providers` 18 · `adms-protocol` 11 · `BiometricPage` 16 · `BiometricLedger` 6 · `biometric.sdk` 6 · `hr-units` 4.


## ملاحظات تشغيل (00172)
- **وسيط Cloudflare Worker**: أجهزة ZKTeco تتجاهل مسار URL وترسل إلى جذر المضيف `/iclock/*`، وSupabase لا يخدم الجذر. لذا يُنشر Worker (مثل `akaram-bio.<حساب>.workers.dev`) يمرّر الطلب كما هو إلى `https://<ref>.supabase.co/functions/v1/adms-receiver` + المسار + الاستعلام. على الجهاز: Domain ON، العنوان = اسم مضيف الـ Worker فقط، المنفذ 443، HTTPS ON.
- **داخل Supabase يصل المسار بلا `/functions/v1`** (`/adms-receiver/iclock/...`) — المستقبل يطبّعه عبر `normalizeAdmsPath`.
- **«آخر اتصال»** تتحدث من نبضة `getrequest` (كل `Delay=10` ثانية) عبر `public.biometric_touch` (غلاف لـ `app.biometric_touch`)، ومن كل دفعة بيانات. «متصل» = نبضة خلال آخر دقيقتين.
- **أسماء المستخدمين**: الجهاز لا يرسلها تلقائياً؛ يُرسل له `C:<id>:DATA QUERY USERINFO` في نبضة (تلقائياً عند التسجيل الأول وعند وجود PIN بلا اسم كل 12 ساعة، أو يدوياً من بطاقة الجهاز «جلب أسماء المستخدمين»). يرد الجهاز بسطور `USER PIN=…\tName=…` (جدول OPERLOG أو USERINFO) فتُحفظ في `biometric_device_users` وتظهر في دفتر البصمة ولوحة «بصمات بلا موظف».
- **تشخيص الاتصال (00173)**: بطاقة جهاز ADMS ← «تشخيص الاتصال»: ① اختبار من المتصفح لرابط الدالة وللعنوان المُدخل في الجهاز (طلب تسجيل وهمي `SN=PLATFORM-TEST` — لا يُسجَّل)، ② فحوصات من القاعدة بالترتيب الفعلي (تسجيل → نبض → بصمات → أسماء → غير مطابَق) مع أوقات وتلميحات، ③ آخر 12 حدثاً. يتحدث كل 10 ثوانٍ. المستقبل يرد برؤوس CORS ويقبل OPTIONS لهذا الغرض فقط.
- **وسيط Cloudflare مع الاختبار من المتصفح**: أضف إلى رد الـ Worker الرأس `Access-Control-Allow-Origin: *` وإلا سيقول الفحص «تعذّر الوصول من المتصفح» رغم أن الجهاز يتصل.

## 00175 — وحدة «الأشخاص غير المطابقين» + الإرسال التلقائي
- `biometric_unmatched_report(from, to, branch?, search?)` (≤ 62 يوماً): صف لكل (جهاز، PIN) بلا موظف؛ `days[]` بتوقيت الجهاز: present (بصمتان+، دقائق = آخر − أول) / missing (واحدة) / absent (لا شيء، حتى اليوم فقط، كل الأيام أيام عمل).
- الصفحة: HR `/hr/biometric/unmatched` (رابط من دفتر البصمة + «ربط بموظف» → `?pin=`) و IT `/it/integrations/biometric/unmatched` (قراءة). تصدير Excel: ورقة شبكة (صف/شخص، عمود/يوم ملوّن، مجاميع) + ورقة تفاصيل يومية.
- محفّز `trg_employee_biometric_autopush`: إضافة موظف برقم بصمة رقمي أو تغيير رقمه/اسمه → أمر USERINFO تلقائي لكل أجهزة ADMS النشطة (لا شيء للمنتهية خدمتهم أو بلا رقم).

## 00176 — الإرسال إلى أجهزة مختارة وحماية مسؤول الجهاز
- `biometric_push_employee(employee, device_ids uuid[] | null)`: null = أجهزة فرع الموظف؛ الواجهة تعرض قائمة اختيار (أجهزة الفرع محددة افتراضياً). المحفّز التلقائي → أجهزة فرع الموظف فقط (بلا فرع → لا شيء).
- سطر USERINFO يحافظ على `Pri`/`Card` المعروفين من `biometric_device_users` ولا يرسل `Passwd=` (حتى لا تُسقط صلاحية/كلمة مرور مسؤول الجهاز إذا تطابق رقمه مع رقم موظف).
- `biometric_set_device_admin(device, pin, name?)` (IT): يرفع المستخدم إلى Pri=14 لاستعادة الدخول إلى قائمة الجهاز عند «رفض الوصول».

## 00177 — إيقاف الأوامر + تدقيق دورة الحضور
- `biometric_command_cancel(id)`: إلغاء أمر «بانتظار اتصال الجهاز» فقط (الحالة `cancelled`)؛ المُرسل للجهاز لا يُلغى. زر «إيقاف» في سجل الأوامر.
- دورة الحضور (`app.hr_evaluate_day`): لا غياب قبل نهاية الدوام ولا لأيام مستقبلية (الإجازة المعتمدة تُكتب دائماً)؛ الزمنية تغطي ما يقع داخلها فقط (`app.hr_permit_cover_minutes`)؛ السماح ينطبق على الخروج المبكر في الحالة؛ خارج مدة الخدمة تُزال الصفوف التلقائية؛ تغيير الشفت يعيد الاحتساب من تاريخ السريان. الاختبار الشامل: `tests/db/hr-attendance-lifecycle-test.sql` (L1–L8).

## 00178 — دقة تعديلات غرفة العمليات + تبليغ التطوير المركزية + أرقام إنكليزية
- **الأرقام**: كل تنسيق تاريخ/وقت/رقم في المنصة يستخدم `ar-IQ-u-nu-latn` (أرقام 0-9) — عقد اختبار `tests/unit/contracts/latin-digits.test.ts` يمنع أي `'ar'`/`'ar-IQ'` بلا `nu-latn`. أوقات الحضور تُعرض بتوقيت بغداد (`timeZone: 'Asia/Baghdad'`) مهما كان توقيت جهاز المستخدم.
- **تعديل غرفة العمليات** (`ops_attendance_edit`): يكمل الدوام المتوقع من الشفت إن لم يوجد صف، يحتسب التأخير والخروج المبكر بنفس قواعد المحرك (السماح + تغطية الزمنيات)، يرفض التواريخ المستقبلية (`HR_FUTURE_DATE`)، ويحدّث التنبيهات. الأوقات في النموذج تُحفظ بإزاحة +03:00 ثابتة.
- **التبليغ**: أي إجراء من غرفة العمليات (تعديل/إعادة احتساب/استقطاع يدوي/إلغاء استقطاع) يُنشئ إشعاراً (`category = 'hr'`) لحسابات `it_admin`/`super_admin` (عدا المنفّذ) عبر trigger على `hr_attendance_audit`، والنماذج تُظهر «سيتم تبليغ وحدة التطوير المركزية».
- **صفحة IT**: `/it/integrations/biometric/attendance-audit` «سجل تعديلات الحضور» (قراءة فقط) عبر `hr_attendance_audit_list` بأسماء الموظف والمدقّق والفرق قبل/بعد. الاختبار: `tests/db/hr-ops-attendance-edit-test.sql` (O1–O6).

## 00179 — إعدادات محرك البصمة + اكتمال كشف المالية (الجولة 2)
- **إعدادات (بوابة التطوير المركزية → سياسة الحضور)**: `punch_window_hours` (1–12، افتراضي 4) نافذة التقاط البصمات حول الدوام؛ `auto_evaluate_enabled` مفتاح الاحتساب التلقائي (المحفّزات + الاحتساب اليومي؛ اليدوي يبقى)؛ `evaluate_lookback_days` (1–31، افتراضي 2).
- **كشف المالية مكتمل**: `app.hr_month_summary` يشمل كل موظف على الملاك خلال الشهر (حتى بلا بصمة) بصفوف صفرية، ويستثني المؤرشف ومن أُنهيت خدمته قبل الشهر أو عُيّن بعده.
- **شفافية الكشف**: `hr_employee_month_days(employee, month)` للمالية/العمليات/HR/التطوير؛ زر «الأيام» في كشف المالية؛ الكشف مجمّع حسب القسم بمجاميع فرعية؛ Excel بورقة ثانية «ملخص الأقسام». الاختبار: `tests/db/hr-engine-settings-payroll-test.sql` (S1–S5).
